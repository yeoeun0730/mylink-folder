import { ProfileData } from '../types';

export const initialProfileData: ProfileData = {
  name: "여은 (Yeoeun)",
  bio: "디자인과 코딩의 경계를 넘나들며 유용한 경험을 짓습니다. 아름다운 인터페이스와 부드러운 인터랙션에 진심인 크리에이터 ✨",
  avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80",
  avatarType: "emoji",
  avatarEmoji: "🌸",
  statusBadge: "🟢 Open for projects",
  statusMood: "🎧 감성 플리 들으며 코딩 중",
  theme: "lavender",
  socials: [
    { platform: "instagram", url: "https://instagram.com", enabled: true },
    { platform: "github", url: "https://github.com", enabled: true },
    { platform: "blog", url: "https://velog.io", enabled: true },
    { platform: "notion", url: "https://notion.so", enabled: true },
    { platform: "linkedin", url: "https://linkedin.com", enabled: true },
    { platform: "email", url: "mailto:contact@example.com", enabled: true },
  ],
  links: [
    {
      id: "link-1",
      title: "💻 나만의 포트폴리오 웹사이트 2026",
      description: "풀스택 웹 애플리케이션 및 디자인 시스템 프로젝트 모음",
      url: "https://github.com",
      icon: "💻",
      badge: "대표작 🌟",
      isFeatured: true,
      clicks: 248,
      category: "Portfolio",
    },
    {
      id: "link-2",
      title: "🚀 AI 사이드 프로젝트 쇼케이스",
      description: "Next.js & LLM 기반 인터랙티브 서비스 런칭 회고",
      url: "https://github.com",
      icon: "✨",
      badge: "NEW 🔥",
      isFeatured: true,
      clicks: 184,
      category: "Project",
    },
    {
      id: "link-3",
      title: "📝 기술 & 디자인 블로그 (Tech Log)",
      description: "배운 것을 기록하고 나누는 주간 개발 아티클",
      url: "https://velog.io",
      icon: "✍️",
      badge: "매주 연재 📚",
      isFeatured: false,
      clicks: 135,
      category: "Blog",
    },
    {
      id: "link-4",
      title: "📋 노션 이력서 & 상세 경력기술서",
      description: "프로젝트 성과, 보유 기술 스택 및 작업 히스토리",
      url: "https://notion.so",
      icon: "📋",
      badge: "Resume 📄",
      isFeatured: false,
      clicks: 94,
      category: "Resume",
    },
    {
      id: "link-5",
      title: "☕ 1:1 커피챗 & 프로젝트 협업 제안",
      description: "가벼운 티타임부터 프로젝트 문의까지 편하게 보내주세요",
      url: "https://open.kakao.com",
      icon: "💬",
      badge: "환영해요 🎉",
      isFeatured: false,
      clicks: 77,
      category: "Contact",
    },
    {
      id: "link-6",
      title: "🎧 새벽 코딩할 때 듣는 Lo-Fi 플레이리스트",
      description: "집중력을 극대화해주는 잔잔한 칠 음악 믹스셋",
      url: "https://youtube.com",
      icon: "🎶",
      badge: "Lo-Fi 🌿",
      isFeatured: false,
      clicks: 219,
      category: "Music",
    },
  ],
};

export const themeStyles: Record<
  string,
  {
    name: string;
    background: string;
    aurora1: string;
    aurora2: string;
    cardBg: string;
    cardBorder: string;
    cardHover: string;
    textColor: string;
    subTextColor: string;
    accentBadge: string;
    tagBg: string;
    featuredBorder: string;
    buttonColor: string;
  }
> = {
  lavender: {
    name: "오로라 라벤더",
    background: "bg-[#faf8ff] text-slate-900",
    aurora1: "bg-purple-300/40 mix-blend-multiply",
    aurora2: "bg-pink-300/40 mix-blend-multiply",
    cardBg: "bg-white/70 backdrop-blur-xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] shadow-purple-500/5",
    cardBorder: "border border-purple-200/50 shadow-[inset_0_1px_1px_rgba(255,255,255,0.9)]",
    cardHover: "hover:shadow-2xl hover:shadow-purple-500/10 hover:border-purple-300/70 hover:-translate-y-1 active:scale-[0.99]",
    textColor: "text-slate-900",
    subTextColor: "text-slate-500",
    accentBadge: "bg-purple-100/80 text-purple-700 border border-purple-200/60 shadow-xs",
    tagBg: "bg-pink-100/80 text-pink-700",
    featuredBorder: "ring-1 ring-purple-400/80 shadow-lg shadow-purple-200/50",
    buttonColor: "bg-purple-600 hover:bg-purple-700 text-white shadow-lg shadow-purple-300/50",
  },
  midnight: {
    name: "옵시디언 다크",
    background: "bg-[#050508] text-slate-100",
    aurora1: "bg-cyan-500/20 mix-blend-screen",
    aurora2: "bg-purple-600/20 mix-blend-screen",
    cardBg: "bg-zinc-900/60 backdrop-blur-xl shadow-[0_8px_30px_rgb(0,0,0,0.5)]",
    cardBorder: "border border-white/10 shadow-[inset_0_1px_0_rgba(255,255,255,0.1)]",
    cardHover: "hover:shadow-2xl hover:shadow-cyan-500/15 hover:border-cyan-400/50 hover:-translate-y-1 active:scale-[0.99]",
    textColor: "text-slate-50",
    subTextColor: "text-zinc-400",
    accentBadge: "bg-cyan-950/70 text-cyan-300 border border-cyan-700/50 shadow-xs",
    tagBg: "bg-purple-950/70 text-purple-300",
    featuredBorder: "ring-1 ring-cyan-400/70 shadow-lg shadow-cyan-500/20",
    buttonColor: "bg-cyan-400 hover:bg-cyan-300 text-black font-bold shadow-lg shadow-cyan-400/20",
  },
  sunset: {
    name: "선셋 코랄",
    background: "bg-[#fffaf6] text-stone-900",
    aurora1: "bg-amber-300/40 mix-blend-multiply",
    aurora2: "bg-rose-300/40 mix-blend-multiply",
    cardBg: "bg-white/70 backdrop-blur-xl shadow-[0_8px_30px_rgb(0,0,0,0.04)]",
    cardBorder: "border border-orange-200/60 shadow-[inset_0_1px_1px_rgba(255,255,255,0.9)]",
    cardHover: "hover:shadow-2xl hover:shadow-orange-500/10 hover:border-orange-300 hover:-translate-y-1 active:scale-[0.99]",
    textColor: "text-stone-900",
    subTextColor: "text-stone-500",
    accentBadge: "bg-orange-100/80 text-orange-700 border border-orange-200/60 shadow-xs",
    tagBg: "bg-rose-100/80 text-rose-700",
    featuredBorder: "ring-1 ring-orange-400/80 shadow-lg shadow-orange-200/50",
    buttonColor: "bg-orange-500 hover:bg-orange-600 text-white shadow-lg shadow-orange-300/50",
  },
  emerald: {
    name: "말차 세이지",
    background: "bg-[#f7faf8] text-slate-900",
    aurora1: "bg-emerald-300/35 mix-blend-multiply",
    aurora2: "bg-teal-200/40 mix-blend-multiply",
    cardBg: "bg-white/70 backdrop-blur-xl shadow-[0_8px_30px_rgb(0,0,0,0.04)]",
    cardBorder: "border border-emerald-200/60 shadow-[inset_0_1px_1px_rgba(255,255,255,0.9)]",
    cardHover: "hover:shadow-2xl hover:shadow-emerald-500/10 hover:border-emerald-300 hover:-translate-y-1 active:scale-[0.99]",
    textColor: "text-slate-900",
    subTextColor: "text-slate-500",
    accentBadge: "bg-emerald-100/80 text-emerald-700 border border-emerald-200/60 shadow-xs",
    tagBg: "bg-teal-100/80 text-teal-700",
    featuredBorder: "ring-1 ring-emerald-400/80 shadow-lg shadow-emerald-200/50",
    buttonColor: "bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-300/50",
  },
  minimal: {
    name: "티타늄 모노",
    background: "bg-[#f4f4f5] dark:bg-[#09090b] text-zinc-900 dark:text-zinc-50",
    aurora1: "bg-zinc-300/30 dark:bg-zinc-700/20",
    aurora2: "bg-zinc-400/20 dark:bg-zinc-800/20",
    cardBg: "bg-white/80 dark:bg-zinc-900/80 backdrop-blur-xl shadow-xs",
    cardBorder: "border border-zinc-200 dark:border-zinc-800 shadow-[inset_0_1px_0_rgba(255,255,255,0.6)] dark:shadow-[inset_0_1px_0_rgba(255,255,255,0.05)]",
    cardHover: "hover:shadow-xl hover:border-zinc-400 dark:hover:border-zinc-600 hover:-translate-y-1 active:scale-[0.99]",
    textColor: "text-zinc-900 dark:text-zinc-50",
    subTextColor: "text-zinc-500 dark:text-zinc-400",
    accentBadge: "bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700",
    tagBg: "bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400",
    featuredBorder: "ring-1 ring-zinc-800 dark:ring-zinc-200 shadow-md",
    buttonColor: "bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 hover:bg-zinc-800 dark:hover:bg-zinc-200 font-bold",
  },
};

"use client";

import React, { useState } from "react";
import { useAuth } from "../lib/authContext";
import { CloseIcon, GoogleIcon, GitHubIcon, KakaoIcon, CheckIcon } from "./Icons";


interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AuthModal({ isOpen, onClose }: AuthModalProps) {
  const { currentUser, signInWithSocial, signInWithEmail, signOut, isLoading } = useAuth();
  const [tab, setTab] = useState<"social" | "email">("social");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  if (!isOpen) return null;

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    await signInWithEmail(email);
    onClose();
  };

  const handleSocialLogin = async (provider: "google" | "github" | "kakao") => {
    await signInWithSocial(provider);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-sm rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl p-6 relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center gap-2">
            <span className="text-xl">🔐</span>
            <div>
              <h3 className="font-bold text-base text-zinc-900 dark:text-zinc-100">
                {currentUser ? "내 계정 정보" : "Firebase 인증 로그인"}
              </h3>
              <p className="text-[11px] text-zinc-400">OAuth 2.0 & Firebase Auth</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800"
          >
            <CloseIcon className="w-5 h-5" />
          </button>
        </div>

        {currentUser ? (
          /* User Logged In State */
          <div className="my-6 space-y-4">
            <div className="p-4 bg-purple-50 dark:bg-purple-950/40 rounded-2xl border border-purple-200 dark:border-purple-900 flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-purple-200 dark:bg-purple-800 flex items-center justify-center text-xl font-bold text-purple-700 dark:text-purple-200 overflow-hidden">
                {currentUser.photoURL ? (
                  <img src={currentUser.photoURL} alt={currentUser.displayName || ""} className="w-full h-full object-cover" />
                ) : (
                  <span>👤</span>
                )}
              </div>
              <div className="overflow-hidden">
                <div className="flex items-center gap-1.5">
                  <p className="font-bold text-sm text-zinc-900 dark:text-zinc-100 truncate">{currentUser.displayName}</p>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-200 dark:bg-purple-900 text-purple-800 dark:text-purple-300 font-bold">소유자</span>
                </div>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 truncate">{currentUser.email}</p>
                <p className="text-[10px] text-zinc-400 font-mono mt-0.5">UID: {currentUser.uid}</p>
              </div>
            </div>

            <div className="p-3 bg-zinc-50 dark:bg-zinc-800/60 rounded-xl border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-600 dark:text-zinc-300">
              <p className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold mb-1">
                <CheckIcon className="w-3.5 h-3.5" />
                Firebase Auth 인증 세션 활성화됨
              </p>
              <p className="text-[11px] text-zinc-400">
                소유자 권한으로 링크 인라인 편집, 생성, 삭제 및 테마 변경이 가능합니다.
              </p>
            </div>

            <button
              onClick={async () => {
                await signOut();
                onClose();
              }}
              disabled={isLoading}
              className="w-full py-2.5 rounded-xl border border-red-300 dark:border-red-900/60 text-red-600 dark:text-red-400 font-semibold text-xs hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
            >
              로그아웃 (방문자 모드로 전환)
            </button>
          </div>
        ) : (
          /* Login Form & Social Buttons */
          <div className="my-5 space-y-4">
            {/* Tab switch */}
            <div className="flex bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setTab("social")}
                className={`flex-1 py-1.5 rounded-lg transition-all ${
                  tab === "social"
                    ? "bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs"
                    : "text-zinc-500"
                }`}
              >
                소셜 로그인 (OAuth)
              </button>
              <button
                onClick={() => setTab("email")}
                className={`flex-1 py-1.5 rounded-lg transition-all ${
                  tab === "email"
                    ? "bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs"
                    : "text-zinc-500"
                }`}
              >
                이메일 로그인
              </button>
            </div>

            {tab === "social" ? (
              <div className="space-y-2.5">
                {/* Google */}
                <button
                  onClick={() => handleSocialLogin("google")}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2.5 py-2.5 px-4 rounded-2xl border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 text-xs font-semibold transition-all shadow-xs"
                >
                  <GoogleIcon className="w-4 h-4" />
                  <span>Google 계정으로 시작하기</span>
                </button>

                {/* GitHub */}
                <button
                  onClick={() => handleSocialLogin("github")}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2.5 py-2.5 px-4 rounded-2xl bg-zinc-900 hover:bg-black text-white text-xs font-semibold transition-all shadow-xs"
                >
                  <GitHubIcon className="w-4 h-4" />
                  <span>GitHub 계정으로 시작하기</span>
                </button>

                {/* Kakao */}
                <button
                  onClick={() => handleSocialLogin("kakao")}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2.5 py-2.5 px-4 rounded-2xl bg-[#FEE500] hover:bg-[#FDD835] text-[#3C1E1E] text-xs font-semibold transition-all shadow-xs"
                >
                  <KakaoIcon className="w-4 h-4" />
                  <span>카카오로 3초 만에 시작하기</span>
                </button>
              </div>
            ) : (
              <form onSubmit={handleEmailSubmit} className="space-y-3">
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                    이메일 주소
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none focus:ring-2 focus:ring-purple-400"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                    비밀번호
                  </label>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none focus:ring-2 focus:ring-purple-400"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition-all shadow-sm"
                >
                  {isLoading ? "인증 처리 중..." : "로그인"}
                </button>
              </form>
            )}

            <div className="p-3 bg-zinc-50 dark:bg-zinc-800/40 rounded-xl text-[10px] text-zinc-400 leading-relaxed">
              💡 <strong>Firebase Auth 특징</strong>: OAuth 팝업을 통해 Google/GitHub의 JWT ID 토큰을 교환받아 클라이언트 상태를 실시간(`onAuthStateChanged`)으로 동기화합니다.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

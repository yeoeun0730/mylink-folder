"use client";

import React, { useState } from "react";
import { ProfileData, LinkItem } from "../types";
import { CloseIcon, PlusIcon, TrashIcon, UpIcon, DownIcon, RefreshIcon, UploadIcon, CameraIcon } from "./Icons";
import { initialProfileData } from "../data/defaultData";
import { compressAndReadImage } from "../lib/fileUpload";

interface EditModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: ProfileData;
  onSave: (newData: ProfileData) => void;
  onReset: () => void;
}

const presetEmojis = ["🌸", "💻", "🦊", "🎨", "🚀", "🌿", "🍓", "🐱", "✨", "☕", "🦄", "🎧"];

export default function EditModal({ isOpen, onClose, data, onSave, onReset }: EditModalProps) {
  const [activeTab, setActiveTab] = useState<"profile" | "links" | "socials" | "backup">("links");
  const [formData, setFormData] = useState<ProfileData>(data);

  // New link form state
  const [newLinkTitle, setNewLinkTitle] = useState("");
  const [newLinkUrl, setNewLinkUrl] = useState("");
  const [newLinkDesc, setNewLinkDesc] = useState("");
  const [newLinkBadge, setNewLinkBadge] = useState("");
  const [newLinkIcon, setNewLinkIcon] = useState("🔗");
  const [newLinkFeatured, setNewLinkFeatured] = useState(false);

  // JSON import state
  const [importJsonText, setImportJsonText] = useState("");
  const [importError, setImportError] = useState("");

  if (!isOpen) return null;

  const handleProfileFieldChange = (field: keyof ProfileData, value: unknown) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleAddLink = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLinkTitle || !newLinkUrl) return;

    let formattedUrl = newLinkUrl.trim();
    if (!/^https?:\/\//i.test(formattedUrl) && !formattedUrl.startsWith("mailto:")) {
      formattedUrl = "https://" + formattedUrl;
    }

    const newLink: LinkItem = {
      id: "link-" + Date.now(),
      title: newLinkTitle.trim(),
      url: formattedUrl,
      description: newLinkDesc.trim() || undefined,
      badge: newLinkBadge.trim() || undefined,
      icon: newLinkIcon || "🔗",
      isFeatured: newLinkFeatured,
      clicks: 0,
    };

    setFormData((prev) => ({
      ...prev,
      links: [newLink, ...prev.links],
    }));

    setNewLinkTitle("");
    setNewLinkUrl("");
    setNewLinkDesc("");
    setNewLinkBadge("");
    setNewLinkIcon("🔗");
    setNewLinkFeatured(false);
  };

  const handleDeleteLink = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      links: prev.links.filter((l) => l.id !== id),
    }));
  };

  const handleMoveLink = (index: number, direction: "up" | "down") => {
    const newLinks = [...formData.links];
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newLinks.length) return;

    const temp = newLinks[index];
    newLinks[index] = newLinks[targetIndex];
    newLinks[targetIndex] = temp;

    setFormData((prev) => ({ ...prev, links: newLinks }));
  };

  const handleSocialChange = (index: number, field: "url" | "enabled", value: unknown) => {
    const updatedSocials = [...formData.socials];
    updatedSocials[index] = {
      ...updatedSocials[index],
      [field]: value,
    };
    setFormData((prev) => ({ ...prev, socials: updatedSocials }));
  };

  const handleSaveAndClose = () => {
    onSave(formData);
    onClose();
  };

  const handleImportJson = () => {
    try {
      setImportError("");
      const parsed = JSON.parse(importJsonText);
      if (parsed.name && parsed.links) {
        setFormData(parsed);
        onSave(parsed);
        alert("성공적으로 데이터를 불러왔습니다!");
      } else {
        setImportError("올바른 마이링크 데이터 형식이 아닙니다.");
      }
    } catch {
      setImportError("JSON 파싱 오류: 올바른 JSON 문자열을 입력해주세요.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg max-h-[90vh] rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl flex flex-col relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center gap-2">
            <span className="text-xl">⚙️</span>
            <h3 className="font-bold text-lg text-zinc-900 dark:text-zinc-100">마이링크 편집 & 설정</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <CloseIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-zinc-100 dark:border-zinc-800 px-6 gap-2 bg-zinc-50/50 dark:bg-zinc-900/50 overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab("links")}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === "links"
                ? "border-purple-600 text-purple-600 dark:text-purple-400 font-bold"
                : "border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-300"
            }`}
          >
            🔗 링크 관리 ({formData.links.length})
          </button>
          <button
            onClick={() => setActiveTab("profile")}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === "profile"
                ? "border-purple-600 text-purple-600 dark:text-purple-400 font-bold"
                : "border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-300"
            }`}
          >
            👤 프로필 정보
          </button>
          <button
            onClick={() => setActiveTab("socials")}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === "socials"
                ? "border-purple-600 text-purple-600 dark:text-purple-400 font-bold"
                : "border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-300"
            }`}
          >
            🌐 소셜 채널
          </button>
          <button
            onClick={() => setActiveTab("backup")}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === "backup"
                ? "border-purple-600 text-purple-600 dark:text-purple-400 font-bold"
                : "border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-300"
            }`}
          >
            💾 데이터 / 초기화
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* TAB 1: LINKS MANAGEMENT */}
          {activeTab === "links" && (
            <div className="space-y-6">
              {/* Add New Link Card */}
              <div className="p-4 rounded-2xl bg-purple-50/70 dark:bg-purple-950/20 border border-purple-200/60 dark:border-purple-900/40">
                <h4 className="text-xs font-bold text-purple-900 dark:text-purple-300 mb-3 flex items-center gap-1.5">
                  <PlusIcon className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                  새 링크 카드 추가하기
                </h4>
                <form onSubmit={handleAddLink} className="space-y-2.5">
                  <div className="grid grid-cols-4 gap-2">
                    <input
                      type="text"
                      placeholder="아이콘 (예: 💻)"
                      value={newLinkIcon}
                      onChange={(e) => setNewLinkIcon(e.target.value)}
                      className="col-span-1 px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none text-center"
                    />
                    <input
                      type="text"
                      required
                      placeholder="링크 제목 (필수)"
                      value={newLinkTitle}
                      onChange={(e) => setNewLinkTitle(e.target.value)}
                      className="col-span-3 px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none font-medium"
                    />
                  </div>
                  <input
                    type="text"
                    required
                    placeholder="URL (예: https://...)"
                    value={newLinkUrl}
                    onChange={(e) => setNewLinkUrl(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none font-mono"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="간단 설명 (선택)"
                      value={newLinkDesc}
                      onChange={(e) => setNewLinkDesc(e.target.value)}
                      className="px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none"
                    />
                    <input
                      type="text"
                      placeholder="뱃지 태그 (예: 추천, HOT)"
                      value={newLinkBadge}
                      onChange={(e) => setNewLinkBadge(e.target.value)}
                      className="px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none"
                    />
                  </div>
                  <div className="flex items-center justify-between pt-1">
                    <label className="flex items-center gap-2 text-xs text-zinc-600 dark:text-zinc-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={newLinkFeatured}
                        onChange={(e) => setNewLinkFeatured(e.target.checked)}
                        className="rounded text-purple-600 focus:ring-purple-400"
                      />
                      <span>✨ 대표 강조 링크로 설정 (반짝임 효과)</span>
                    </label>
                    <button
                      type="submit"
                      className="px-4 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-sm transition-all"
                    >
                      추가
                    </button>
                  </div>
                </form>
              </div>

              {/* Link List */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-wider">현재 링크 목록 ({formData.links.length})</h4>
                {formData.links.map((link, idx) => (
                  <div
                    key={link.id}
                    className="p-3 bg-zinc-50 dark:bg-zinc-800/60 rounded-2xl border border-zinc-200/80 dark:border-zinc-700/80 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3 overflow-hidden">
                      <span className="text-xl shrink-0 p-1 bg-white dark:bg-zinc-700 rounded-xl shadow-xs">{link.icon || "🔗"}</span>
                      <div className="truncate">
                        <div className="flex items-center gap-2">
                          <p className="font-bold text-zinc-800 dark:text-zinc-100 truncate">{link.title}</p>
                          {link.badge && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-300 font-semibold shrink-0">
                              {link.badge}
                            </span>
                          )}
                          {link.isFeatured && (
                            <span className="text-[10px] text-amber-500 font-bold shrink-0">★ 강조</span>
                          )}
                        </div>
                        <p className="text-[11px] text-zinc-400 font-mono truncate">{link.url}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => handleMoveLink(idx, "up")}
                        disabled={idx === 0}
                        className="p-1 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-white dark:hover:bg-zinc-700 disabled:opacity-30"
                        title="위로 이동"
                      >
                        <UpIcon className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleMoveLink(idx, "down")}
                        disabled={idx === formData.links.length - 1}
                        className="p-1 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-white dark:hover:bg-zinc-700 disabled:opacity-30"
                        title="아래로 이동"
                      >
                        <DownIcon className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteLink(link.id)}
                        className="p-1 rounded-lg text-zinc-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                        title="삭제"
                      >
                        <TrashIcon className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: PROFILE SETTINGS */}
          {activeTab === "profile" && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-zinc-700 dark:text-zinc-300 mb-2">프로필 사진 / 아바타 설정</label>
                
                {/* Avatar Type Selector */}
                <div className="flex items-center gap-3 mb-3">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="avatarType"
                      checked={formData.avatarType === "image"}
                      onChange={() => handleProfileFieldChange("avatarType", "image")}
                    />
                    <span className="font-semibold">사진 파일 업로드 / 이미지</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      name="avatarType"
                      checked={formData.avatarType === "emoji"}
                      onChange={() => handleProfileFieldChange("avatarType", "emoji")}
                    />
                    <span className="font-semibold">이모지 아바타</span>
                  </label>
                </div>

                {formData.avatarType === "image" ? (
                  <div className="space-y-3 p-3 bg-zinc-50 dark:bg-zinc-800/80 rounded-2xl border border-zinc-200 dark:border-zinc-700">
                    <div className="flex items-center gap-3">
                      {/* Current Photo Preview */}
                      <div className="w-16 h-16 rounded-full bg-zinc-200 dark:bg-zinc-700 overflow-hidden shrink-0 border-2 border-purple-400 shadow-sm flex items-center justify-center">
                        {formData.avatarUrl ? (
                          <img src={formData.avatarUrl} alt="Preview" className="w-full h-full object-cover" />
                        ) : (
                          <CameraIcon className="w-6 h-6 text-zinc-400" />
                        )}
                      </div>

                      {/* File Upload Button */}
                      <div className="flex-1 space-y-1.5">
                        <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs cursor-pointer shadow-xs transition-colors">
                          <UploadIcon className="w-3.5 h-3.5" />
                          <span>내 컴퓨터에서 사진 파일 선택</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                try {
                                  const compressed = await compressAndReadImage(file);
                                  handleProfileFieldChange("avatarUrl", compressed);
                                  handleProfileFieldChange("avatarType", "image");
                                } catch (err: unknown) {
                                  alert(err instanceof Error ? err.message : "파일 업로드 실패");
                                }
                              }
                            }}
                          />
                        </label>
                        <p className="text-[10px] text-zinc-400">JPG, PNG, GIF, WebP (자동 웹 최적화 압축)</p>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-semibold text-zinc-500 mb-1">또는 이미지 URL 직접 입력</label>
                      <input
                        type="text"
                        placeholder="https://images.unsplash.com/..."
                        value={formData.avatarUrl}
                        onChange={(e) => handleProfileFieldChange("avatarUrl", e.target.value)}
                        className="w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 outline-none font-mono"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2 p-3 bg-zinc-50 dark:bg-zinc-800/80 rounded-2xl border border-zinc-200 dark:border-zinc-700">
                    {presetEmojis.map((emoji) => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => handleProfileFieldChange("avatarEmoji", emoji)}
                        className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg transition-all ${
                          formData.avatarEmoji === emoji
                            ? "bg-purple-100 dark:bg-purple-900/60 ring-2 ring-purple-500 scale-110 shadow-sm"
                            : "hover:bg-zinc-200 dark:hover:bg-zinc-700"
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <label className="block font-bold text-zinc-700 dark:text-zinc-300 mb-1">이름 / 닉네임</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleProfileFieldChange("name", e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none text-zinc-800 dark:text-zinc-100 font-semibold"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-700 dark:text-zinc-300 mb-1">한 줄 소개 (Bio)</label>
                <textarea
                  rows={3}
                  value={formData.bio}
                  onChange={(e) => handleProfileFieldChange("bio", e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none text-zinc-800 dark:text-zinc-100 leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-zinc-700 dark:text-zinc-300 mb-1">상태 뱃지</label>
                  <input
                    type="text"
                    placeholder="예: 🟢 작업 및 협업 가능"
                    value={formData.statusBadge}
                    onChange={(e) => handleProfileFieldChange("statusBadge", e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-zinc-700 dark:text-zinc-300 mb-1">현재 무드 / 상태 메시지</label>
                  <input
                    type="text"
                    placeholder="예: 🎧 플리 들으며 코딩 중"
                    value={formData.statusMood}
                    onChange={(e) => handleProfileFieldChange("statusMood", e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: SOCIAL CHANNELS */}
          {activeTab === "socials" && (
            <div className="space-y-3 text-xs">
              <p className="text-zinc-500">소셜 미디어 프로필 링크를 입력하고 표시 여부를 토글하세요.</p>
              {formData.socials.map((social, idx) => (
                <div key={social.platform} className="p-3 bg-zinc-50 dark:bg-zinc-800 rounded-2xl border border-zinc-200 dark:border-zinc-700 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold capitalize text-zinc-800 dark:text-zinc-200">{social.platform}</span>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={social.enabled}
                        onChange={(e) => handleSocialChange(idx, "enabled", e.target.checked)}
                        className="rounded text-purple-600 focus:ring-purple-400"
                      />
                      <span>활성화</span>
                    </label>
                  </div>
                  {social.enabled && (
                    <input
                      type="text"
                      value={social.url}
                      onChange={(e) => handleSocialChange(idx, "url", e.target.value)}
                      placeholder={`https://${social.platform}.com/...`}
                      className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 font-mono outline-none"
                    />
                  )}
                </div>
              ))}
            </div>
          )}

          {/* TAB 4: BACKUP & RESET */}
          {activeTab === "backup" && (
            <div className="space-y-4 text-xs">
              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 space-y-3">
                <h4 className="font-bold text-zinc-800 dark:text-zinc-200 flex items-center gap-1.5">
                  <RefreshIcon className="w-4 h-4 text-purple-600" />
                  기본값으로 복원
                </h4>
                <p className="text-zinc-500">처음 제공된 여은의 기본 프로필과 링크 데이터로 초기화합니다.</p>
                <button
                  type="button"
                  onClick={() => {
                    if (confirm("정말로 모든 설정을 초기 기본 데이터로 되돌리시겠습니까?")) {
                      setFormData(initialProfileData);
                      onReset();
                      alert("기본 데이터로 초기화되었습니다.");
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl bg-red-100 hover:bg-red-200 text-red-700 font-semibold transition-colors"
                >
                  기본 데이터로 리셋하기
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 space-y-3">
                <h4 className="font-bold text-zinc-800 dark:text-zinc-200">데이터 백업 & 복원 (JSON)</h4>
                <div>
                  <label className="block text-zinc-500 mb-1">현재 설정 JSON 내보내기:</label>
                  <textarea
                    rows={4}
                    readOnly
                    value={JSON.stringify(formData, null, 2)}
                    className="w-full p-2 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 font-mono text-[10px] select-all outline-none"
                  />
                </div>
                <div>
                  <label className="block text-zinc-500 mb-1">JSON 데이터 가져오기:</label>
                  <textarea
                    rows={3}
                    placeholder="백업했던 JSON 문자열을 붙여넣으세요"
                    value={importJsonText}
                    onChange={(e) => setImportJsonText(e.target.value)}
                    className="w-full p-2 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 font-mono text-[10px] outline-none"
                  />
                  {importError && <p className="text-red-500 text-[11px] mt-1">{importError}</p>}
                  <button
                    type="button"
                    onClick={handleImportJson}
                    className="mt-2 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-semibold transition-colors"
                  >
                    JSON 적용하기
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Footer */}
        <div className="px-6 py-3.5 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-end gap-2 bg-zinc-50/50 dark:bg-zinc-900/50">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-xs font-semibold transition-colors"
          >
            취소
          </button>
          <button
            onClick={handleSaveAndClose}
            className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-md shadow-purple-300/40 dark:shadow-none transition-all"
          >
            변경사항 저장하기
          </button>
        </div>
      </div>
    </div>
  );
}

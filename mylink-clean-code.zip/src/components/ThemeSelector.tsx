"use client";

import React from "react";
import { ThemeType } from "../types";

interface ThemeSelectorProps {
  currentTheme: ThemeType;
  onThemeChange: (theme: ThemeType) => void;
}

const themeOptions: { id: ThemeType; label: string; dotColor: string }[] = [
  { id: "lavender", label: "라벤더", dotColor: "bg-purple-500 shadow-purple-400/50" },
  { id: "midnight", label: "다크", dotColor: "bg-cyan-400 shadow-cyan-400/50" },
  { id: "sunset", label: "선셋", dotColor: "bg-orange-500 shadow-orange-400/50" },
  { id: "emerald", label: "말차", dotColor: "bg-emerald-500 shadow-emerald-400/50" },
  { id: "minimal", label: "모노", dotColor: "bg-zinc-800 dark:bg-zinc-200 shadow-zinc-400/50" },
];

export default function ThemeSelector({ currentTheme, onThemeChange }: ThemeSelectorProps) {
  return (
    <div className="flex items-center gap-1 p-1 bg-white/80 dark:bg-zinc-900/80 backdrop-blur-2xl rounded-full shadow-sm border border-black/5 dark:border-white/10">
      {themeOptions.map((opt) => {
        const isActive = currentTheme === opt.id;
        return (
          <button
            key={opt.id}
            onClick={() => onThemeChange(opt.id)}
            title={`${opt.label} 테마`}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs transition-all duration-200 ${
              isActive
                ? "bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-xs font-bold scale-105"
                : "text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 hover:bg-black/5 dark:hover:bg-white/5"
            }`}
          >
            <span className={`w-2.5 h-2.5 rounded-full ${opt.dotColor} shadow-xs shrink-0`} />
            <span className="hidden sm:inline font-medium">{opt.label}</span>
          </button>
        );
      })}
    </div>
  );
}

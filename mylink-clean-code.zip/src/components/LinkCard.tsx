"use client";

import React, { useState } from "react";
import { LinkItem } from "../types";
import { themeStyles } from "../data/defaultData";
import { ExternalLinkIcon, EditIcon, TrashIcon, CheckIcon, SparklesIcon } from "./Icons";

interface LinkCardProps {
  link: LinkItem;
  theme: string;
  isOwner: boolean;
  onUpdate: (linkId: string, partial: Partial<LinkItem>) => void;
  onRequestDelete: (link: LinkItem) => void;
  onLinkClick: (link: LinkItem) => void;
}

export default function LinkCard({
  link,
  theme,
  isOwner,
  onUpdate,
  onRequestDelete,
  onLinkClick,
}: LinkCardProps) {
  const currentTheme = themeStyles[theme] || themeStyles.lavender;

  // Inline edit state
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(link.title);
  const [editDesc, setEditDesc] = useState(link.description || "");

  const handleSaveInline = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!editTitle.trim()) return;

    onUpdate(link.id, {
      title: editTitle.trim(),
      description: editDesc.trim() || undefined,
    });
    setIsEditing(false);
  };

  const handleCancelInline = () => {
    setEditTitle(link.title);
    setEditDesc(link.description || "");
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSaveInline();
    } else if (e.key === "Escape") {
      handleCancelInline();
    }
  };

  const handleCardClick = (e: React.MouseEvent) => {
    if (isEditing) return;
    const target = e.target as HTMLElement;
    if (target.closest("button") || target.closest("input")) return;

    onLinkClick(link);

    // If file attachment, trigger direct download
    if (link.isAttachment && link.url.startsWith("data:")) {
      const a = document.createElement("a");
      a.href = link.url;
      a.download = link.fileName || `${link.title}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      return;
    }

    window.open(link.url, "_blank", "noopener,noreferrer");
  };

  const cardContent = (
    <div
      onClick={handleCardClick}
      className={`relative w-full rounded-[22px] p-4.5 transition-all duration-300 cursor-pointer ${
        currentTheme.cardBg
      } ${currentTheme.cardBorder} ${currentTheme.cardHover} ${
        link.isFeatured ? currentTheme.featuredBorder : ""
      }`}
    >
      {/* Featured Pill */}
      {link.isFeatured && (
        <div className="absolute -top-2.5 right-5 flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-linear-to-r from-purple-600 via-pink-600 to-amber-500 text-white text-[10px] font-extrabold shadow-md shadow-pink-500/20 tracking-wider">
          <SparklesIcon className="w-3 h-3" />
          <span>FEATURED</span>
        </div>
      )}

      {isEditing ? (
        /* INLINE EDITING UI MODE */
        <div
          onClick={(e) => e.stopPropagation()}
          className="space-y-3 animate-in fade-in duration-150"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-purple-600 dark:text-purple-400">
              <EditIcon className="w-3.5 h-3.5" />
              <span>카드 인라인 편집 (Update)</span>
            </div>
            <span className="text-[10px] text-zinc-400 font-mono">ESC 취소 / Enter 저장</span>
          </div>

          <input
            type="text"
            required
            value={editTitle}
            onChange={(e) => setEditTitle(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="링크 제목 입력"
            className="w-full px-3.5 py-2 text-xs font-bold rounded-xl bg-white dark:bg-zinc-800 border-2 border-purple-500 text-zinc-900 dark:text-zinc-100 outline-none shadow-sm"
            autoFocus
          />

          <input
            type="text"
            value={editDesc}
            onChange={(e) => setEditDesc(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="부제목 및 설명 문구 입력 (선택)"
            className="w-full px-3.5 py-1.5 text-[11px] rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 outline-none"
          />

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={handleCancelInline}
              className="px-3 py-1.5 rounded-xl text-xs text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
            >
              취소
            </button>
            <button
              type="button"
              onClick={() => handleSaveInline()}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-md shadow-purple-300/40 dark:shadow-none transition-all cursor-pointer"
            >
              <CheckIcon className="w-3.5 h-3.5" />
              <span>저장하기</span>
            </button>
          </div>
        </div>
      ) : (
        /* NORMAL MODERN DISPLAY MODE */
        <div className="flex items-center justify-between gap-3.5">
          {/* Left: Icon & Title/Description */}
          <div className="flex items-center gap-3.5 min-w-0">
            {/* Bento-style Icon Box */}
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shrink-0 bg-white dark:bg-zinc-800/90 shadow-sm border border-black/5 dark:border-white/10 group-hover:scale-110 group-hover:rotate-2 transition-transform duration-300">
              {link.icon || "🔗"}
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className={`text-sm font-extrabold tracking-tight truncate ${currentTheme.textColor} group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors`}>
                  {link.title}
                </h4>
                {link.badge && (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${currentTheme.tagBg}`}
                  >
                    {link.badge}
                  </span>
                )}
              </div>
              {link.description && (
                <p className={`text-xs mt-1 line-clamp-1 leading-relaxed font-medium ${currentTheme.subTextColor}`}>
                  {link.description}
                </p>
              )}
            </div>
          </div>

          {/* Right: Counter & Action */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Clicks counter badge */}
            <span
              className="text-[10px] font-mono font-medium px-2.5 py-1 rounded-full bg-zinc-100/90 dark:bg-zinc-800/80 text-zinc-500 dark:text-zinc-400 border border-black/5 dark:border-white/5"
              title="클릭 수"
            >
              👁️ {link.clicks || 0}
            </span>

            {/* Owner action controls */}
            {isOwner ? (
              <div
                onClick={(e) => e.stopPropagation()}
                className="flex items-center gap-1"
              >
                <button
                  type="button"
                  onClick={() => setIsEditing(true)}
                  className="p-2 rounded-xl text-zinc-400 hover:text-purple-600 hover:bg-purple-100/70 dark:hover:bg-purple-950/50 transition-colors"
                  title="카드 인라인 편집 (Update)"
                >
                  <EditIcon className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => onRequestDelete(link)}
                  className="p-2 rounded-xl text-zinc-400 hover:text-red-600 hover:bg-red-100/70 dark:hover:bg-red-950/50 transition-colors"
                  title="링크 삭제 (Delete)"
                >
                  <TrashIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              /* Visitor Arrow Badge */
              <div className="w-8 h-8 rounded-full bg-zinc-100/90 dark:bg-zinc-800/80 flex items-center justify-center text-zinc-400 group-hover:bg-purple-600 group-hover:text-white transition-all duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 shadow-xs">
                <ExternalLinkIcon className="w-3.5 h-3.5" />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="group relative w-full">
      {cardContent}
    </div>
  );
}

"use client";

import React, { useState } from "react";

export default function MusicWidget() {
  const [isPlaying, setIsPlaying] = useState(true);

  return (
    <div className="w-full rounded-2xl p-3.5 bg-white/70 dark:bg-zinc-900/70 backdrop-blur-xl border border-black/5 dark:border-white/10 shadow-xs flex items-center justify-between gap-3 group transition-all duration-300 hover:shadow-md">
      <div className="flex items-center gap-3 min-w-0">
        {/* Animated Vinyl / Album Art */}
        <div 
          onClick={() => setIsPlaying(!isPlaying)}
          className={`w-10 h-10 rounded-xl bg-linear-to-tr from-purple-500 via-pink-500 to-indigo-600 p-0.5 shadow-md shrink-0 cursor-pointer flex items-center justify-center transition-transform active:scale-95`}
        >
          <div className={`w-full h-full rounded-[10px] bg-zinc-950 flex items-center justify-center text-xs ${isPlaying ? "animate-spin [animation-duration:6s]" : ""}`}>
            💿
          </div>
        </div>

        {/* Music Info */}
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Now Playing
            </span>
            <span className="w-1 h-1 rounded-full bg-zinc-400" />
            <span className="text-[10px] text-zinc-400 font-mono">Lo-Fi Beats</span>
          </div>
          <p className="text-xs font-bold text-zinc-800 dark:text-zinc-100 truncate group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
            NewJeans - Bubble Gum (Chillhop Mix)
          </p>
        </div>
      </div>

      {/* Equalizer & Play/Pause Button */}
      <div className="flex items-center gap-2.5 shrink-0">
        {isPlaying ? (
          <div className="flex items-end gap-[2px] h-4 px-1" title="재생 중">
            <span className="w-[3px] bg-purple-500 dark:bg-purple-400 rounded-full animate-eq-1" />
            <span className="w-[3px] bg-pink-500 dark:bg-pink-400 rounded-full animate-eq-2" />
            <span className="w-[3px] bg-indigo-500 dark:bg-indigo-400 rounded-full animate-eq-3" />
            <span className="w-[3px] bg-purple-500 dark:bg-purple-400 rounded-full animate-eq-4" />
          </div>
        ) : (
          <span className="text-[10px] text-zinc-400 font-mono">PAUSED</span>
        )}

        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="w-7 h-7 rounded-full bg-zinc-100 dark:bg-zinc-800 hover:bg-purple-100 dark:hover:bg-purple-950/60 text-zinc-700 dark:text-zinc-300 hover:text-purple-600 dark:hover:text-purple-400 flex items-center justify-center text-xs transition-colors shadow-xs"
          title={isPlaying ? "일시정지" : "재생"}
        >
          {isPlaying ? "⏸" : "▶"}
        </button>
      </div>
    </div>
  );
}

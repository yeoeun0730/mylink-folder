"use client";

import React, { useState, useEffect } from "react";
import { CloseIcon, HeartIcon, PlusIcon, TrashIcon } from "./Icons";
import { GuestbookEntry } from "../types";

interface GuestbookModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const defaultEntries: GuestbookEntry[] = [
  {
    id: "guest-1",
    author: "민우",
    content: "마이링크 너무 깔끔하고 예뻐요! 포트폴리오 잘 보고 갑니다 ✨",
    emoji: "🎉",
    createdAt: "2026-11-14",
  },
  {
    id: "guest-2",
    author: "지수",
    content: "커피챗 신청했어요! 플레이리스트 취향도 딱 제 스타일이네요 🎧☕",
    emoji: "💖",
    createdAt: "2026-11-13",
  },
  {
    id: "guest-3",
    author: "서연",
    content: "앞으로의 멋진 프로젝트들도 항상 응원할게요! 파이팅 🍀",
    emoji: "🍀",
    createdAt: "2026-11-12",
  },
];

const emojiList = ["💖", "🎉", "☕", "🌟", "🍀", "🔥", "🚀", "🌸"];

export default function GuestbookModal({ isOpen, onClose }: GuestbookModalProps) {
  const [entries, setEntries] = useState<GuestbookEntry[]>([]);
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [selectedEmoji, setSelectedEmoji] = useState("💖");
  const [heartsCount, setHeartsCount] = useState(128);
  const [hasCheered, setHasCheered] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("mylink_guestbook");
      if (saved) {
        try {
          setEntries(JSON.parse(saved));
        } catch {
          setEntries(defaultEntries);
        }
      } else {
        setEntries(defaultEntries);
      }

      const savedHearts = localStorage.getItem("mylink_cheers_count");
      if (savedHearts) {
        setHeartsCount(parseInt(savedHearts, 10));
      }
    }
  }, []);

  const saveEntries = (newEntries: GuestbookEntry[]) => {
    setEntries(newEntries);
    if (typeof window !== "undefined") {
      localStorage.setItem("mylink_guestbook", JSON.stringify(newEntries));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const newEntry: GuestbookEntry = {
      id: "guest-" + Date.now(),
      author: name.trim() || "익명의 친구",
      content: message.trim(),
      emoji: selectedEmoji,
      createdAt: new Date().toISOString().split("T")[0],
    };

    const updated = [newEntry, ...entries];
    saveEntries(updated);
    setName("");
    setMessage("");
  };

  const handleDelete = (id: string) => {
    const updated = entries.filter((item) => item.id !== id);
    saveEntries(updated);
  };

  const handleCheerHeart = () => {
    const nextCount = heartsCount + 1;
    setHeartsCount(nextCount);
    setHasCheered(true);
    if (typeof window !== "undefined") {
      localStorage.setItem("mylink_cheers_count", nextCount.toString());
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md max-h-[85vh] rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl p-6 flex flex-col relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-zinc-100 dark:border-zinc-800 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xl">💌</span>
            <h3 className="font-bold text-lg text-zinc-900 dark:text-zinc-100">한 줄 방명록 & 응원</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <CloseIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Cheer Heart Button */}
        <div className="my-3 p-3 bg-pink-50 dark:bg-pink-950/40 rounded-2xl border border-pink-200 dark:border-pink-900/50 flex items-center justify-between shrink-0">
          <div>
            <p className="text-xs font-semibold text-pink-700 dark:text-pink-300">오늘의 응원 하트</p>
            <p className="text-sm font-bold text-pink-900 dark:text-pink-100">{heartsCount}개의 하트를 받았어요!</p>
          </div>
          <button
            onClick={handleCheerHeart}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all transform active:scale-95 ${
              hasCheered
                ? "bg-pink-600 text-white shadow-md shadow-pink-300 dark:shadow-none"
                : "bg-white dark:bg-zinc-800 text-pink-600 dark:text-pink-300 border border-pink-200 dark:border-pink-700 hover:bg-pink-100"
            }`}
          >
            <HeartIcon className="w-4 h-4" fill={hasCheered} />
            <span>응원 꾹!</span>
          </button>
        </div>

        {/* Message Input Form */}
        <form onSubmit={handleSubmit} className="space-y-2 mb-4 shrink-0">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="이름/닉네임 (선택)"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-1/3 px-3 py-1.5 text-xs rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200 outline-none focus:ring-2 focus:ring-purple-400"
            />
            {/* Emoji selector */}
            <div className="flex gap-1 overflow-x-auto py-0.5">
              {emojiList.map((emoji) => (
                <button
                  type="button"
                  key={emoji}
                  onClick={() => setSelectedEmoji(emoji)}
                  className={`w-7 h-7 flex items-center justify-center rounded-lg text-sm transition-all ${
                    selectedEmoji === emoji
                      ? "bg-purple-100 dark:bg-purple-900/60 ring-2 ring-purple-500 scale-110"
                      : "hover:bg-zinc-100 dark:hover:bg-zinc-800 opacity-80"
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              required
              placeholder="따뜻한 한 줄 응원 메시지를 남겨보세요 ✨"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="flex-1 px-3 py-2 text-xs rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200 outline-none focus:ring-2 focus:ring-purple-400"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold flex items-center gap-1 shadow-sm shrink-0"
            >
              <PlusIcon className="w-3.5 h-3.5" />
              <span>등록</span>
            </button>
          </div>
        </form>

        {/* Entries List */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {entries.length === 0 ? (
            <p className="text-center py-8 text-xs text-zinc-400">아직 작성된 방명록이 없습니다. 첫 응원을 남겨보세요!</p>
          ) : (
            entries.map((entry) => (
              <div
                key={entry.id}
                className="p-3 bg-zinc-50 dark:bg-zinc-800/60 rounded-2xl border border-zinc-200/60 dark:border-zinc-800 flex items-start justify-between gap-3 text-xs"
              >
                <div className="flex items-start gap-2.5">
                  <span className="text-xl p-1 bg-white dark:bg-zinc-700 rounded-xl shadow-xs shrink-0">{entry.emoji}</span>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{entry.author}</span>
                      <span className="text-[10px] text-zinc-400">{entry.createdAt}</span>
                    </div>
                    <p className="mt-0.5 text-zinc-600 dark:text-zinc-300 leading-relaxed">{entry.content}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleDelete(entry.id)}
                  className="text-zinc-400 hover:text-red-500 p-1 transition-colors"
                  title="삭제"
                >
                  <TrashIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

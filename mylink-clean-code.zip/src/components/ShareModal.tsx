"use client";

import React, { useState } from "react";
import { CloseIcon, CopyIcon, CheckIcon, ShareIcon } from "./Icons";

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
}

export default function ShareModal({ isOpen, onClose, title }: ShareModalProps) {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== "undefined" ? window.location.href : "https://mylink.me";

  const handleCopy = async () => {
    try {
      if (typeof navigator !== "undefined" && navigator.clipboard) {
        await navigator.clipboard.writeText(currentUrl);
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      }
    } catch {
      // fallback
    }
  };

  const handleNativeShare = async () => {
    if (typeof navigator !== "undefined" && navigator.share) {
      try {
        await navigator.share({
          title: title,
          text: `${title}의 마이링크에 방문해보세요!`,
          url: currentUrl,
        });
      } catch {
        // user canceled
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-sm rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl p-6 relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center gap-2">
            <ShareIcon className="w-5 h-5 text-purple-600 dark:text-purple-400" />
            <h3 className="font-bold text-lg text-zinc-900 dark:text-zinc-100">마이링크 공유하기</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
            aria-label="닫기"
          >
            <CloseIcon className="w-5 h-5" />
          </button>
        </div>

        {/* QR Code Section */}
        <div className="flex flex-col items-center my-6">
          <div className="p-3 bg-white rounded-2xl shadow-inner border border-zinc-200/80 dark:border-zinc-700 flex items-center justify-center">
            {/* SVG stylized QR code representation */}
            <svg className="w-36 h-36 text-zinc-900" viewBox="0 0 100 100" fill="currentColor">
              {/* Top-left marker */}
              <rect x="10" y="10" width="28" height="28" rx="4" fill="currentColor" />
              <rect x="14" y="14" width="20" height="20" rx="2" fill="white" />
              <rect x="18" y="18" width="12" height="12" rx="2" fill="currentColor" />

              {/* Top-right marker */}
              <rect x="62" y="10" width="28" height="28" rx="4" fill="currentColor" />
              <rect x="66" y="14" width="20" height="20" rx="2" fill="white" />
              <rect x="70" y="18" width="12" height="12" rx="2" fill="currentColor" />

              {/* Bottom-left marker */}
              <rect x="10" y="62" width="28" height="28" rx="4" fill="currentColor" />
              <rect x="14" y="66" width="20" height="20" rx="2" fill="white" />
              <rect x="18" y="70" width="12" height="12" rx="2" fill="currentColor" />

              {/* Data dots */}
              <rect x="44" y="14" width="6" height="6" rx="1.5" />
              <rect x="52" y="14" width="6" height="6" rx="1.5" />
              <rect x="44" y="24" width="6" height="6" rx="1.5" />
              <rect x="44" y="32" width="14" height="6" rx="1.5" />

              <rect x="14" y="44" width="6" height="12" rx="1.5" />
              <rect x="26" y="44" width="8" height="6" rx="1.5" />
              <rect x="36" y="44" width="6" height="6" rx="1.5" />
              <rect x="44" y="44" width="12" height="12" rx="2" />
              <rect x="60" y="44" width="8" height="6" rx="1.5" />
              <rect x="74" y="44" width="14" height="6" rx="1.5" />

              <rect x="22" y="54" width="14" height="4" rx="1" />
              <rect x="60" y="54" width="6" height="12" rx="1.5" />
              <rect x="72" y="54" width="8" height="6" rx="1.5" />

              <rect x="44" y="62" width="8" height="8" rx="1.5" />
              <rect x="56" y="66" width="6" height="14" rx="1.5" />
              <rect x="68" y="66" width="12" height="6" rx="1.5" />
              <rect x="44" y="76" width="6" height="12" rx="1.5" />
              <rect x="68" y="76" width="6" height="12" rx="1.5" />
              <rect x="80" y="76" width="8" height="12" rx="1.5" />
            </svg>
          </div>
          <p className="mt-2 text-xs text-zinc-500 dark:text-zinc-400 font-medium">
            스마트폰 카메라로 비추면 바로 열립니다
          </p>
        </div>

        {/* Link Input & Copy */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 p-2 bg-zinc-100 dark:bg-zinc-800 rounded-2xl border border-zinc-200 dark:border-zinc-700">
            <input
              type="text"
              readOnly
              value={currentUrl}
              className="bg-transparent text-xs text-zinc-700 dark:text-zinc-300 font-mono w-full px-2 outline-none overflow-ellipsis"
            />
            <button
              onClick={handleCopy}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all duration-200 ${
                copied
                  ? "bg-emerald-500 text-white"
                  : "bg-purple-600 hover:bg-purple-700 text-white shadow-sm"
              }`}
            >
              {copied ? (
                <>
                  <CheckIcon className="w-3.5 h-3.5" />
                  <span>복사됨!</span>
                </>
              ) : (
                <>
                  <CopyIcon className="w-3.5 h-3.5" />
                  <span>복사</span>
                </>
              )}
            </button>
          </div>

          <button
            onClick={handleNativeShare}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 text-sm font-semibold hover:opacity-90 transition-opacity"
          >
            <ShareIcon className="w-4 h-4" />
            <span>SNS / 메신저로 바로 공유하기</span>
          </button>
        </div>
      </div>
    </div>
  );
}

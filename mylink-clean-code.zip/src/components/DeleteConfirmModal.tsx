"use client";

import React, { useState } from "react";
import { LinkItem } from "../types";
import { TrashIcon, CloseIcon } from "./Icons";

interface DeleteConfirmModalProps {
  isOpen: boolean;
  link: LinkItem | null;
  onClose: () => void;
  onConfirm: (linkId: string, isSoftDelete: boolean) => void;
}

export default function DeleteConfirmModal({
  isOpen,
  link,
  onClose,
  onConfirm,
}: DeleteConfirmModalProps) {
  const [isSoftDelete, setIsSoftDelete] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  if (!isOpen || !link) return null;

  const handleConfirm = async () => {
    setIsDeleting(true);
    await new Promise((resolve) => setTimeout(resolve, 300));
    onConfirm(link.id, isSoftDelete);
    setIsDeleting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-sm rounded-3xl bg-white dark:bg-zinc-900 border border-red-200 dark:border-red-900/60 shadow-2xl p-6 relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Warning Icon Badge */}
        <div className="flex items-center justify-between pb-3 border-b border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 flex items-center justify-center">
              <TrashIcon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-zinc-900 dark:text-zinc-100">링크 삭제 확인</h3>
              <p className="text-[11px] text-zinc-400">파괴적 작업(Delete Action) 주의</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800"
          >
            <CloseIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Content Box */}
        <div className="my-5 space-y-3">
          <p className="text-xs text-zinc-600 dark:text-zinc-300 leading-relaxed">
            아래 링크 카드를 삭제하시겠습니까? 이 작업은 마이링크 페이지에서 해당 링크를 제거합니다.
          </p>

          <div className="p-3.5 bg-red-50/60 dark:bg-red-950/30 rounded-2xl border border-red-200/70 dark:border-red-900/40">
            <div className="flex items-center gap-2">
              <span className="text-base">{link.icon || "🔗"}</span>
              <p className="font-bold text-xs text-red-900 dark:text-red-200 truncate">{link.title}</p>
            </div>
            <p className="text-[10px] text-zinc-500 dark:text-zinc-400 font-mono mt-1 truncate">{link.url}</p>
          </div>

          {/* Soft Delete vs Hard Delete Option */}
          <div className="p-3 bg-zinc-50 dark:bg-zinc-800/60 rounded-xl border border-zinc-200 dark:border-zinc-700/60 text-xs">
            <label className="flex items-start gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isSoftDelete}
                onChange={(e) => setIsSoftDelete(e.target.checked)}
                className="mt-0.5 rounded text-red-600 focus:ring-red-400"
              />
              <div>
                <span className="font-semibold text-zinc-800 dark:text-zinc-200">소프트 딜리트 (임시 비활성화)</span>
                <p className="text-[11px] text-zinc-400">DB에서 영구 삭제하지 않고 화면에서만 숨김 처리합니다.</p>
              </div>
            </label>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-2 pt-2">
          <button
            onClick={onClose}
            disabled={isDeleting}
            className="px-4 py-2 rounded-xl border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 text-xs font-semibold hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            취소
          </button>
          <button
            onClick={handleConfirm}
            disabled={isDeleting}
            className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md shadow-red-300/40 dark:shadow-none transition-all flex items-center gap-1.5"
          >
            {isDeleting ? "삭제 처리 중..." : "확인 및 삭제"}
          </button>
        </div>
      </div>
    </div>
  );
}

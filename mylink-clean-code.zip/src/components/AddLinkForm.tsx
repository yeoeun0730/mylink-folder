"use client";

import React, { useState } from "react";
import { LinkItem } from "../types";
import { PlusIcon, CheckIcon, SparklesIcon, UploadIcon, FileIcon } from "./Icons";
import { readAttachmentFile } from "../lib/fileUpload";

interface AddLinkFormProps {
  onAdd: (newLink: Omit<LinkItem, "id" | "clicks">) => void;
}

const quickEmojis = ["💻", "📝", "📋", "☕", "🎵", "🎨", "🚀", "🔗", "✨", "📌"];

export default function AddLinkForm({ onAdd }: AddLinkFormProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [formType, setFormType] = useState<"url" | "file">("url");

  // Form Fields
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [description, setDescription] = useState("");
  const [icon, setIcon] = useState("🔗");
  const [badge, setBadge] = useState("");
  const [isFeatured, setIsFeatured] = useState(false);
  const [category, setCategory] = useState("Portfolio");

  // File Upload State
  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    sizeFormatted: string;
    dataUrl: string;
  } | null>(null);
  const [isReadingFile, setIsReadingFile] = useState(false);

  // Validation States
  const [touched, setTouched] = useState({ title: false, url: false });

  // URL regex check
  const urlRegex = /^(https?:\/\/)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(:\d+)?(\/[^\s]*)?$/;

  const isTitleValid = title.trim().length >= 2 && title.trim().length <= 50;
  const isUrlValid = formType === "file" ? Boolean(uploadedFile?.dataUrl) : urlRegex.test(url.trim());
  const isFormValid = isTitleValid && isUrlValid;

  const handleFileSelect = async (file: File) => {
    setIsReadingFile(true);
    try {
      const result = await readAttachmentFile(file);
      setUploadedFile({
        name: result.name,
        sizeFormatted: result.sizeFormatted,
        dataUrl: result.dataUrl,
      });

      // Auto-populate form
      if (!title) {
        setTitle(result.name);
      }
      setDescription(`첨부 파일 다운로드 (${result.sizeFormatted})`);
      setUrl(result.dataUrl);

      // Icon auto selection
      if (result.type.includes("pdf")) {
        setIcon("📄");
        setBadge(`PDF • ${result.sizeFormatted}`);
        setCategory("Resume");
      } else if (result.type.startsWith("image/")) {
        setIcon("🎨");
        setBadge(`IMAGE • ${result.sizeFormatted}`);
        setCategory("Portfolio");
      } else if (result.type.includes("zip") || result.type.includes("tar")) {
        setIcon("📦");
        setBadge(`ZIP • ${result.sizeFormatted}`);
        setCategory("Project");
      } else {
        setIcon("📁");
        setBadge(`FILE • ${result.sizeFormatted}`);
      }
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : "파일을 읽는 중 오류가 발생했습니다.");
    } finally {
      setIsReadingFile(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid) return;

    let finalUrl = url.trim();
    if (formType === "url") {
      if (!/^https?:\/\//i.test(finalUrl) && !finalUrl.startsWith("mailto:")) {
        finalUrl = "https://" + finalUrl;
      }
    } else if (uploadedFile) {
      finalUrl = uploadedFile.dataUrl;
    }

    onAdd({
      title: title.trim(),
      url: finalUrl,
      description: description.trim() || undefined,
      icon: icon || "🔗",
      badge: badge.trim() || undefined,
      isFeatured,
      category,
      fileName: uploadedFile?.name,
      fileSize: uploadedFile?.sizeFormatted,
      isAttachment: formType === "file",
    });

    // Reset Form
    setTitle("");
    setUrl("");
    setDescription("");
    setBadge("");
    setIsFeatured(false);
    setUploadedFile(null);
    setTouched({ title: false, url: false });
    setIsOpen(false);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="w-full py-3.5 px-4 rounded-2xl border-2 border-dashed border-purple-300 dark:border-purple-800 hover:border-purple-500 dark:hover:border-purple-600 bg-white/60 dark:bg-zinc-900/60 hover:bg-purple-50/50 dark:hover:bg-purple-950/20 text-purple-700 dark:text-purple-300 text-xs font-bold transition-all duration-200 flex items-center justify-center gap-2 group shadow-xs cursor-pointer"
      >
        <div className="w-6 h-6 rounded-lg bg-purple-100 dark:bg-purple-900/60 flex items-center justify-center group-hover:scale-110 transition-transform">
          <PlusIcon className="w-4 h-4 text-purple-600 dark:text-purple-400" />
        </div>
        <span>새로운 링크 또는 파일(PDF/이력서) 올리기</span>
      </button>
    );
  }

  return (
    <div className="w-full p-5 rounded-[26px] bg-white/90 dark:bg-zinc-900/90 border border-purple-400/60 dark:border-purple-700/60 shadow-xl shadow-purple-500/5 backdrop-blur-2xl animate-in fade-in duration-200">
      <div className="flex items-center justify-between pb-3 mb-3 border-b border-zinc-100 dark:border-zinc-800">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-purple-100 dark:bg-purple-900/60 text-purple-600 dark:text-purple-300 flex items-center justify-center">
            <PlusIcon className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-bold text-sm text-zinc-900 dark:text-zinc-100">새 항목 추가 (웹 링크 / 파일 업로드)</h4>
            <p className="text-[10px] text-zinc-400">웹 링크 또는 내 컴퓨터의 문서/PDF 파일을 바로 등록하세요</p>
          </div>
        </div>
        <button
          onClick={() => setIsOpen(false)}
          className="text-xs text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
        >
          닫기
        </button>
      </div>

      {/* Form Type Tabs: Web Link vs File Attachment */}
      <div className="flex p-1 bg-zinc-100 dark:bg-zinc-800 rounded-xl mb-3.5 text-xs font-bold">
        <button
          type="button"
          onClick={() => setFormType("url")}
          className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
            formType === "url"
              ? "bg-white dark:bg-zinc-700 text-purple-600 dark:text-purple-300 shadow-xs"
              : "text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200"
          }`}
        >
          <span>🔗 일반 웹 링크</span>
        </button>
        <button
          type="button"
          onClick={() => setFormType("file")}
          className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
            formType === "file"
              ? "bg-white dark:bg-zinc-700 text-purple-600 dark:text-purple-300 shadow-xs"
              : "text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200"
          }`}
        >
          <UploadIcon className="w-3.5 h-3.5" />
          <span>📁 내 파일 올리기 (PDF / 문서)</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        {/* FILE UPLOAD DROPZONE (if formType === 'file') */}
        {formType === "file" && (
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
              파일 선택 (PDF, 이력서, 포트폴리오, 문서)
            </label>
            <div className="p-4 rounded-2xl border-2 border-dashed border-purple-300 dark:border-purple-800/80 bg-purple-50/40 dark:bg-purple-950/20 flex flex-col items-center justify-center text-center">
              {uploadedFile ? (
                <div className="flex items-center gap-3 p-2 bg-white dark:bg-zinc-800 rounded-xl border border-purple-200 dark:border-purple-800 w-full">
                  <div className="w-10 h-10 rounded-lg bg-purple-100 dark:bg-purple-900/60 flex items-center justify-center text-xl shrink-0">
                    <FileIcon className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div className="flex-1 text-left min-w-0 truncate">
                    <p className="text-xs font-bold text-zinc-800 dark:text-zinc-100 truncate">{uploadedFile.name}</p>
                    <p className="text-[10px] text-zinc-400 font-mono">{uploadedFile.sizeFormatted} • 준비 완료</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setUploadedFile(null)}
                    className="text-xs text-red-500 hover:underline px-2"
                  >
                    삭제
                  </button>
                </div>
              ) : (
                <label className="flex flex-col items-center cursor-pointer py-2">
                  <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900/60 text-purple-600 dark:text-purple-300 flex items-center justify-center mb-1.5 shadow-xs">
                    <UploadIcon className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-bold text-purple-700 dark:text-purple-300">
                    {isReadingFile ? "파일 읽는 중..." : "컴퓨터에서 파일 선택하기"}
                  </span>
                  <span className="text-[10px] text-zinc-400 mt-0.5">
                    PDF, DOC, ZIP, 이미지 등 최대 6MB
                  </span>
                  <input
                    type="file"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileSelect(file);
                    }}
                  />
                </label>
              )}
            </div>
          </div>
        )}

        {/* Title and Icon */}
        <div className="space-y-1">
          <label className="flex items-center justify-between text-xs font-semibold text-zinc-700 dark:text-zinc-300">
            <span>카드 제목 <span className="text-red-500">*</span></span>
            <span className={`text-[10px] ${title.length > 50 ? "text-red-500" : "text-zinc-400"}`}>
              {title.length}/50자
            </span>
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={icon}
              onChange={(e) => setIcon(e.target.value)}
              className="w-12 text-center text-lg px-2 py-1.5 rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none"
              title="아이콘 이모지"
            />
            <input
              type="text"
              required
              placeholder="예: 📄 2026 여은의 노션 이력서 PDF"
              value={title}
              onBlur={() => setTouched((p) => ({ ...p, title: true }))}
              onChange={(e) => setTitle(e.target.value)}
              className={`flex-1 px-3 py-2 text-xs rounded-xl bg-zinc-50 dark:bg-zinc-800 border outline-none font-medium transition-colors ${
                touched.title && !isTitleValid
                  ? "border-red-400 ring-1 ring-red-400"
                  : "border-zinc-200 dark:border-zinc-700 focus:border-purple-500"
              }`}
            />
          </div>
          {touched.title && !isTitleValid && (
            <p className="text-[10px] text-red-500">제목은 2자 이상 50자 이하로 입력해주세요.</p>
          )}
        </div>

        {/* Quick Emoji Picker */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1 scrollbar-none">
          <span className="text-[10px] text-zinc-400 shrink-0">빠른 아이콘:</span>
          {quickEmojis.map((e) => (
            <button
              key={e}
              type="button"
              onClick={() => setIcon(e)}
              className="p-1 rounded-lg text-sm hover:bg-purple-100 dark:hover:bg-purple-950 transition-colors"
            >
              {e}
            </button>
          ))}
        </div>

        {/* URL Input (only if formType === 'url') */}
        {formType === "url" && (
          <div className="space-y-1">
            <label className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
              연결 웹 URL <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="https://example.com 또는 velog.io/@username"
              value={url}
              onBlur={() => setTouched((p) => ({ ...p, url: true }))}
              onChange={(e) => setUrl(e.target.value)}
              className={`w-full px-3 py-2 text-xs rounded-xl bg-zinc-50 dark:bg-zinc-800 border font-mono outline-none transition-colors ${
                touched.url && !isUrlValid
                  ? "border-red-400 ring-1 ring-red-400"
                  : "border-zinc-200 dark:border-zinc-700 focus:border-purple-500"
              }`}
            />
            {touched.url && !isUrlValid && (
              <p className="text-[10px] text-red-500">올바른 URL 형식(예: https://... 또는 domain.com)을 입력해주세요.</p>
            )}
          </div>
        )}

        {/* Description & Badge */}
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-[11px] font-semibold text-zinc-600 dark:text-zinc-400">설명 문구 (선택)</label>
            <input
              type="text"
              placeholder="예: 최신 작업물 다운로드"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-1.5 text-xs rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none"
            />
          </div>
          <div>
            <label className="text-[11px] font-semibold text-zinc-600 dark:text-zinc-400">강조 뱃지 (선택)</label>
            <input
              type="text"
              placeholder="예: PDF 📄, NEW ✨"
              value={badge}
              onChange={(e) => setBadge(e.target.value)}
              className="w-full px-3 py-1.5 text-xs rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none"
            />
          </div>
        </div>

        {/* Featured Toggle */}
        <div className="flex items-center justify-between pt-1">
          <label className="flex items-center gap-2 text-xs text-zinc-700 dark:text-zinc-300 cursor-pointer">
            <input
              type="checkbox"
              checked={isFeatured}
              onChange={(e) => setIsFeatured(e.target.checked)}
              className="rounded text-purple-600 focus:ring-purple-400"
            />
            <span className="flex items-center gap-1">
              <SparklesIcon className="w-3.5 h-3.5 text-amber-500" />
              <span>대표 강조 카드로 지정 (Featured Glow)</span>
            </span>
          </label>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-100 dark:border-zinc-800">
          <button
            type="button"
            onClick={() => setIsOpen(false)}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            취소
          </button>
          <button
            type="submit"
            disabled={!isFormValid}
            className={`flex items-center gap-1.5 px-5 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
              isFormValid
                ? "bg-purple-600 hover:bg-purple-700 text-white shadow-purple-300/40 dark:shadow-none cursor-pointer"
                : "bg-zinc-200 dark:bg-zinc-800 text-zinc-400 cursor-not-allowed"
            }`}
          >
            <CheckIcon className="w-4 h-4" />
            <span>{formType === "file" ? "파일 카드 등록" : "링크 생성"}</span>
          </button>
        </div>
      </form>
    </div>
  );
}

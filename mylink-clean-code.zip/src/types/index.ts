export interface LinkItem {
  id: string;
  title: string;
  description?: string;
  url: string;
  icon?: string; // emoji or icon name
  badge?: string; // e.g. "HOT", "NEW", "추천", "포트폴리오"
  isFeatured?: boolean;
  clicks: number;
  category?: string;
  fileName?: string;
  fileSize?: string;
  isAttachment?: boolean;
}

export interface SocialLink {
  platform: 'instagram' | 'github' | 'blog' | 'youtube' | 'linkedin' | 'x' | 'email' | 'notion';
  url: string;
  enabled: boolean;
}

export type ThemeType = 'lavender' | 'midnight' | 'sunset' | 'emerald' | 'minimal';

export interface ProfileData {
  name: string;
  bio: string;
  avatarUrl: string;
  avatarType: 'image' | 'emoji';
  avatarEmoji: string;
  statusBadge: string;
  statusMood: string;
  theme: ThemeType;
  socials: SocialLink[];
  links: LinkItem[];
}

export interface GuestbookEntry {
  id: string;
  author: string;
  content: string;
  emoji: string;
  createdAt: string;
}

"use client";

import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { FirebaseUser, DEFAULT_OWNER_USER } from "./firebase";

interface AuthContextType {
  currentUser: FirebaseUser | null;
  isOwner: boolean;
  isLoading: boolean;
  signInWithSocial: (provider: "google" | "github" | "kakao") => Promise<void>;
  signInWithEmail: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
  toggleOwnerMode: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_KEY_AUTH = "mylink_auth_user";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [isOwner, setIsOwner] = useState<boolean>(true); // 기본적으로 편리한 실습을 위해 소유자 모드로 시작
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // onAuthStateChanged 리스너 시뮬레이션
    if (typeof window !== "undefined") {
      try {
        const stored = localStorage.getItem(STORAGE_KEY_AUTH);
        if (stored) {
          const user: FirebaseUser = JSON.parse(stored);
          setCurrentUser(user);
          setIsOwner(user.uid === DEFAULT_OWNER_USER.uid);
        } else {
          // 초기 기본 사용자: 소유자(여은)
          setCurrentUser(DEFAULT_OWNER_USER);
          setIsOwner(true);
        }
      } catch (e) {
        console.error("Auth restore error:", e);
        setCurrentUser(DEFAULT_OWNER_USER);
        setIsOwner(true);
      } finally {
        setIsLoading(false);
      }
    }
  }, []);

  const signInWithSocial = async (provider: "google" | "github" | "kakao") => {
    setIsLoading(true);
    // OAuth 2.0 팝업 로그인 흐름 시뮬레이션
    await new Promise((resolve) => setTimeout(resolve, 600));

    const providerNames: Record<string, string> = {
      google: "Google",
      github: "GitHub",
      kakao: "Kakao",
    };

    const newUser: FirebaseUser = {
      uid: DEFAULT_OWNER_USER.uid, // 데모 목적: 소유자 권한 부여
      displayName: `여은 (${providerNames[provider]} 로그인)`,
      email: `yeoeun@${provider}.auth`,
      photoURL: DEFAULT_OWNER_USER.photoURL,
      providerId: `${provider}.com`,
    };

    setCurrentUser(newUser);
    setIsOwner(true);
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEY_AUTH, JSON.stringify(newUser));
    }
    setIsLoading(false);
  };

  const signInWithEmail = async (email: string) => {
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 500));

    const newUser: FirebaseUser = {
      uid: DEFAULT_OWNER_USER.uid,
      displayName: email.split("@")[0],
      email: email,
      photoURL: null,
      providerId: "password",
    };

    setCurrentUser(newUser);
    setIsOwner(true);
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEY_AUTH, JSON.stringify(newUser));
    }
    setIsLoading(false);
  };

  const signOut = async () => {
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 300));
    setCurrentUser(null);
    setIsOwner(false);
    if (typeof window !== "undefined") {
      localStorage.removeItem(STORAGE_KEY_AUTH);
    }
    setIsLoading(false);
  };

  const toggleOwnerMode = () => {
    setIsOwner((prev) => !prev);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isOwner,
        isLoading,
        signInWithSocial,
        signInWithEmail,
        signOut,
        toggleOwnerMode,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

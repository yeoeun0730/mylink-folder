import { ProfileData, LinkItem } from "../types";
import { initialProfileData } from "../data/defaultData";

const STORAGE_KEY_PROFILE = "mylink_firestore_profile";
const STORAGE_KEY_LINKS = "mylink_firestore_links";

/**
 * Firestore Service Layer
 * 
 * NoSQL Document CRUD 연산 및 낙관적 UI 지원 레이어
 * Firestore SDK의 getDoc, setDoc, updateDoc, deleteDoc 패턴을 따릅니다.
 */

export const firestoreService = {
  // Read Profile: users/{userId}
  async getProfile(): Promise<ProfileData> {
    if (typeof window === "undefined") return initialProfileData;
    try {
      const stored = localStorage.getItem(STORAGE_KEY_PROFILE);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error("Firestore getProfile error:", e);
    }
    return initialProfileData;
  },

  // Update Profile: updateDoc(doc(db, "users", userId), data)
  async updateProfile(data: Partial<ProfileData>): Promise<ProfileData> {
    const current = await this.getProfile();
    const updated = { ...current, ...data };
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEY_PROFILE, JSON.stringify(updated));
    }
    return updated;
  },

  // Read Links: getDocs(collection(db, "users", userId, "links"))
  async getLinks(): Promise<LinkItem[]> {
    if (typeof window === "undefined") return initialProfileData.links;
    try {
      const stored = localStorage.getItem(STORAGE_KEY_LINKS);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error("Firestore getLinks error:", e);
    }
    return initialProfileData.links;
  },

  // Create Link: addDoc(collection(db, "users", userId, "links"), newLink)
  async createLink(newLink: Omit<LinkItem, "id" | "clicks">): Promise<LinkItem> {
    const links = await this.getLinks();
    const item: LinkItem = {
      ...newLink,
      id: "link_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 5),
      clicks: 0,
    };
    const updated = [item, ...links];
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEY_LINKS, JSON.stringify(updated));
    }
    return item;
  },

  // Update Link (Inline or Full): updateDoc(doc(db, "users", userId, "links", linkId), partial)
  async updateLink(linkId: string, partial: Partial<LinkItem>): Promise<LinkItem[]> {
    const links = await this.getLinks();
    const updated = links.map((link) => {
      if (link.id === linkId) {
        return { ...link, ...partial };
      }
      return link;
    });
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEY_LINKS, JSON.stringify(updated));
    }
    return updated;
  },

  // Delete Link: deleteDoc(doc(db, "users", userId, "links", linkId))
  async deleteLink(linkId: string, softDelete = false): Promise<LinkItem[]> {
    const links = await this.getLinks();
    let updated: LinkItem[];
    if (softDelete) {
      // 소프트 딜리트: 플래그 설정
      updated = links.map((l) => (l.id === linkId ? { ...l, isDeleted: true } : l));
    } else {
      // 하드 딜리트: 완전 삭제
      updated = links.filter((link) => link.id !== linkId);
    }
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEY_LINKS, JSON.stringify(updated));
    }
    return updated;
  },

  // Increment Clicks (Atomicity simulation: updateDoc + increment(1))
  async incrementClicks(linkId: string): Promise<number> {
    const links = await this.getLinks();
    let newClicks = 0;
    const updated = links.map((link) => {
      if (link.id === linkId) {
        newClicks = (link.clicks || 0) + 1;
        return { ...link, clicks: newClicks };
      }
      return link;
    });
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEY_LINKS, JSON.stringify(updated));
    }
    return newClicks;
  },

  // Reset to default data
  async resetToDefault(): Promise<{ profile: ProfileData; links: LinkItem[] }> {
    if (typeof window !== "undefined") {
      localStorage.removeItem(STORAGE_KEY_PROFILE);
      localStorage.removeItem(STORAGE_KEY_LINKS);
    }
    return {
      profile: initialProfileData,
      links: initialProfileData.links,
    };
  },
};

/**
 * Firebase & BaaS 아키텍처 연동 모듈
 * 
 * 실제 Firebase 프로젝트 연결과 로컬 시뮬레이션(Emulator/Offline)을 동시에 지원하는
 * 하이브리드 BaaS 클라이언트 레이어입니다.
 * 
 * [Firestore NoSQL 설계 구조]
 * - users/{userId}: 프로필 문서 (name, bio, avatar, theme, status)
 * - users/{userId}/links/{linkId}: 링크 서브컬렉션 (title, url, clicks, isFeatured)
 * - guestbook/{entryId}: 전역 방명록 컬렉션
 */

export interface FirebaseUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  providerId: string;
  isAnonymous?: boolean;
}

// 환경변수 기반 실제 Firebase 설정 여부 확인
export const isRealFirebaseConfigured = Boolean(
  process.env.NEXT_PUBLIC_FIREBASE_API_KEY &&
  process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID
);

export const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "AIzaSyMockKeyForMyLinkApp12345678",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "mylink-ye.firebaseapp.com",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "mylink-ye",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || "mylink-ye.appspot.com",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || "1234567890",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || "1:1234567890:web:abcdef123456",
};

// 기본 소유자(Admin) 목 사용자 정보
export const DEFAULT_OWNER_USER: FirebaseUser = {
  uid: "yeoeun_owner_uid_777",
  email: "yeoeun@mylink.dev",
  displayName: "여은 (Yeoeun)",
  photoURL: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80",
  providerId: "google.com",
};

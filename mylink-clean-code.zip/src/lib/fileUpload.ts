/**
 * 클라이언트 측 파일 업로드 및 이미지 최적화 유틸리티
 * 
 * - 이미지 업로드 시 Canvas를 이용해 자동으로 웹 최적화 리사이징 및 압축
 * - PDF 및 문서 파일의 Base64 인코딩 및 용량 계산
 */

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

export function compressAndReadImage(
  file: File,
  maxWidth = 500,
  maxHeight = 500,
  quality = 0.85
): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      return reject(new Error("이미지 파일만 업로드할 수 있습니다."));
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error("파일 읽기 실패"));
    reader.onload = (event) => {
      const img = new Image();
      img.onerror = () => reject(new Error("이미지 로드 실패"));
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        // 종횡비 유지하면서 리사이징
        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext("2d");
        if (!ctx) {
          return resolve(event.target?.result as string);
        }

        ctx.drawImage(img, 0, 0, width, height);
        // JPEG 또는 WebP로 압축
        const compressedDataUrl = canvas.toDataURL("image/jpeg", quality);
        resolve(compressedDataUrl);
      };

      img.src = event.target?.result as string;
    };

    reader.readAsDataURL(file);
  });
}

export function readAttachmentFile(
  file: File
): Promise<{ dataUrl: string; name: string; sizeFormatted: string; type: string }> {
  return new Promise((resolve, reject) => {
    // 6MB 제한
    const maxBytes = 6 * 1024 * 1024;
    if (file.size > maxBytes) {
      return reject(new Error("파일 용량은 6MB 이하만 업로드 가능합니다."));
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error("파일 읽기 실패"));
    reader.onload = () => {
      resolve({
        dataUrl: reader.result as string,
        name: file.name,
        sizeFormatted: formatFileSize(file.size),
        type: file.type || "application/octet-stream",
      });
    };
    reader.readAsDataURL(file);
  });
}

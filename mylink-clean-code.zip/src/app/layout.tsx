import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "마이링크 (MyLink) | 나만의 프로필 링크",
  description: "나만의 개성 있는 링크와 프로필을 한 곳에서 모아 공유하세요.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ko" className="h-full antialiased">
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}


"use client";

import React, { useState, useEffect, useMemo } from "react";
import { ProfileData, LinkItem, ThemeType } from "../types";
import { themeStyles, initialProfileData } from "../data/defaultData";
import { firestoreService } from "../lib/firestoreService";
import { AuthProvider, useAuth } from "../lib/authContext";
import LinkCard from "../components/LinkCard";
import AddLinkForm from "../components/AddLinkForm";
import MusicWidget from "../components/MusicWidget";
import DeleteConfirmModal from "../components/DeleteConfirmModal";
import AuthModal from "../components/AuthModal";
import ShareModal from "../components/ShareModal";
import GuestbookModal from "../components/GuestbookModal";
import EditModal from "../components/EditModal";
import ThemeSelector from "../components/ThemeSelector";
import {
  InstagramIcon,
  GitHubIcon,
  BlogIcon,
  NotionIcon,
  LinkedInIcon,
  XIcon,
  YouTubeIcon,
  MailIcon,
  ShareIcon,
  SearchIcon,
  SparklesIcon,
  MessageIcon,
  EditIcon,
  CloseIcon,
  HeartIcon,
  CameraIcon,
  UploadIcon,
} from "../components/Icons";
import { compressAndReadImage } from "../lib/fileUpload";

const categoryFilters = ["전체", "Featured", "Portfolio", "Project", "Blog", "Resume", "Contact"];

const techSkills = [
  { name: "Next.js 16", color: "from-purple-500/20 to-indigo-500/20 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800" },
  { name: "TypeScript", color: "from-blue-500/20 to-cyan-500/20 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800" },
  { name: "Tailwind 4", color: "from-cyan-500/20 to-teal-500/20 text-teal-700 dark:text-teal-300 border-teal-200 dark:border-teal-800" },
  { name: "Figma UI/UX", color: "from-rose-500/20 to-pink-500/20 text-pink-700 dark:text-pink-300 border-pink-200 dark:border-pink-800" },
  { name: "Firebase BaaS", color: "from-amber-500/20 to-orange-500/20 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800" },
];

function MyLinkApp() {
  const { isOwner, currentUser, toggleOwnerMode } = useAuth();

  // Core Data States
  const [profile, setProfile] = useState<ProfileData>(initialProfileData);
  const [links, setLinks] = useState<LinkItem[]>(initialProfileData.links);
  const [isLoading, setIsLoading] = useState(true);

  // Search & Category Filter States
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("전체");

  // Live Cheers Heart Counter
  const [cheersCount, setCheersCount] = useState(148);
  const [hasCheered, setHasCheered] = useState(false);

  // Modals state
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isGuestbookOpen, setIsGuestbookOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [deleteTargetLink, setDeleteTargetLink] = useState<LinkItem | null>(null);

  // Toast Notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Initial Load from Firestore Service
  useEffect(() => {
    async function loadData() {
      setIsLoading(true);
      try {
        const [savedProfile, savedLinks] = await Promise.all([
          firestoreService.getProfile(),
          firestoreService.getLinks(),
        ]);
        setProfile(savedProfile);
        setLinks(savedLinks);

        const storedCheers = localStorage.getItem("mylink_cheers_count");
        if (storedCheers) setCheersCount(parseInt(storedCheers, 10));
      } catch (err) {
        console.error("Data load failed:", err);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  // Filter links based on search query & category tab
  const filteredLinks = useMemo(() => {
    return links.filter((l) => {
      // Category match
      if (selectedCategory === "Featured" && !l.isFeatured) return false;
      if (selectedCategory !== "전체" && selectedCategory !== "Featured" && l.category !== selectedCategory) {
        return false;
      }

      // Search match
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        l.title.toLowerCase().includes(q) ||
        (l.description && l.description.toLowerCase().includes(q)) ||
        (l.badge && l.badge.toLowerCase().includes(q)) ||
        l.url.toLowerCase().includes(q)
      );
    });
  }, [links, searchQuery, selectedCategory]);

  // Total clicks calculation
  const totalClicks = useMemo(() => {
    return links.reduce((sum, l) => sum + (l.clicks || 0), 0);
  }, [links]);

  // CRUD: Create
  const handleAddLink = async (newLinkData: Omit<LinkItem, "id" | "clicks">) => {
    try {
      const created = await firestoreService.createLink(newLinkData);
      setLinks((prev) => [created, ...prev]);
      showToast("✨ 새로운 링크 카드가 추가되었습니다!");
    } catch {
      showToast("링크 추가 중 오류가 발생했습니다.");
    }
  };

  // CRUD: Update (Inline or Full)
  const handleUpdateLink = async (linkId: string, partial: Partial<LinkItem>) => {
    try {
      setLinks((prev) =>
        prev.map((l) => (l.id === linkId ? { ...l, ...partial } : l))
      );
      await firestoreService.updateLink(linkId, partial);
      showToast("수정사항이 저장되었습니다.");
    } catch {
      showToast("저장 중 오류가 발생했습니다.");
    }
  };

  // CRUD: Delete
  const handleConfirmDelete = async (linkId: string, isSoftDelete: boolean) => {
    try {
      const updated = await firestoreService.deleteLink(linkId, isSoftDelete);
      setLinks(updated);
      showToast(isSoftDelete ? "링크가 임시 숨김 처리되었습니다." : "링크가 삭제되었습니다.");
    } catch {
      showToast("삭제 중 오류가 발생했습니다.");
    }
  };

  // Link Click Tracking
  const handleLinkClick = async (link: LinkItem) => {
    try {
      setLinks((prev) =>
        prev.map((l) => (l.id === link.id ? { ...l, clicks: (l.clicks || 0) + 1 } : l))
      );
      await firestoreService.incrementClicks(link.id);
    } catch (e) {
      console.error(e);
    }
  };

  // Live Cheer Heart
  const handleQuickCheer = () => {
    const next = cheersCount + 1;
    setCheersCount(next);
    setHasCheered(true);
    if (typeof window !== "undefined") {
      localStorage.setItem("mylink_cheers_count", next.toString());
    }
    showToast("💖 여은님에게 응원 하트를 보냈어요!");
  };

  // Direct Profile Photo File Upload
  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressAndReadImage(file);
      const updated = { ...profile, avatarUrl: compressed, avatarType: "image" as const };
      setProfile(updated);
      await firestoreService.updateProfile(updated);
      showToast("✨ 프로필 사진이 성공적으로 업로드되었습니다!");
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : "사진 업로드 실패");
    }
  };

  // Theme Change Handler
  const handleThemeChange = async (newTheme: ThemeType) => {
    const updated = { ...profile, theme: newTheme };
    setProfile(updated);
    await firestoreService.updateProfile({ theme: newTheme });
  };

  const renderSocialIcon = (platform: string) => {
    const iconClass = "w-4 h-4";
    switch (platform) {
      case "instagram":
        return <InstagramIcon className={iconClass} />;
      case "github":
        return <GitHubIcon className={iconClass} />;
      case "blog":
        return <BlogIcon className={iconClass} />;
      case "notion":
        return <NotionIcon className={iconClass} />;
      case "linkedin":
        return <LinkedInIcon className={iconClass} />;
      case "x":
        return <XIcon className={iconClass} />;
      case "youtube":
        return <YouTubeIcon className={iconClass} />;
      case "email":
        return <MailIcon className={iconClass} />;
      default:
        return <span>🌐</span>;
    }
  };

  const currentTheme = themeStyles[profile.theme] || themeStyles.lavender;

  return (
    <div className={`relative min-h-screen w-full transition-colors duration-700 overflow-x-hidden ${currentTheme.background}`}>
      {/* Dynamic Animated Ambient Aurora Blobs in Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div
          className={`absolute -top-32 -left-32 w-96 h-96 rounded-full blur-3xl opacity-60 ${currentTheme.aurora1} animate-aurora-1`}
        />
        <div
          className={`absolute top-1/3 -right-32 w-[420px] h-[420px] rounded-full blur-3xl opacity-50 ${currentTheme.aurora2} animate-aurora-2`}
        />
        <div
          className={`absolute -bottom-32 left-1/4 w-[380px] h-[380px] rounded-full blur-3xl opacity-40 ${currentTheme.aurora1} animate-aurora-1`}
        />
      </div>

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in slide-in-from-top-4 fade-in duration-200">
          <div className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-zinc-950/90 dark:bg-white/90 text-white dark:text-zinc-950 text-xs font-bold shadow-2xl backdrop-blur-xl border border-white/20 dark:border-zinc-800">
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Modern Capsule Header Bar */}
      <header className="sticky top-3 z-40 w-full px-4 mb-4">
        <div className="max-w-md mx-auto rounded-full p-2 bg-white/70 dark:bg-zinc-900/70 backdrop-blur-2xl border border-black/5 dark:border-white/10 shadow-lg shadow-black/5 flex items-center justify-between gap-2">
          {/* Brand */}
          <div className="flex items-center gap-2 pl-2">
            <span className="w-2.5 h-2.5 rounded-full bg-linear-to-r from-purple-500 to-pink-500 animate-pulse" />
            <span className="font-extrabold text-xs tracking-tight text-zinc-900 dark:text-white">
              마이링크 <span className="text-[10px] text-purple-600 dark:text-purple-400 font-mono">2026</span>
            </span>
          </div>

          {/* Theme & Controls */}
          <div className="flex items-center gap-1.5">
            <ThemeSelector currentTheme={profile.theme} onThemeChange={handleThemeChange} />

            {/* Owner Toggle */}
            <button
              onClick={toggleOwnerMode}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all shadow-xs ${
                isOwner
                  ? "bg-purple-600 text-white shadow-purple-500/25"
                  : "bg-black/5 dark:bg-white/10 text-zinc-700 dark:text-zinc-300 hover:bg-black/10"
              }`}
              title={isOwner ? "방문자 모드로 전환" : "소유자 편집 모드로 전환"}
            >
              {isOwner ? "✏️ 편집" : "👀 뷰"}
            </button>

            {/* Auth Profile Button */}
            <button
              onClick={() => setIsAuthOpen(true)}
              className="w-7 h-7 rounded-full bg-black/5 dark:bg-white/10 text-zinc-700 dark:text-zinc-200 hover:scale-105 transition-transform flex items-center justify-center text-xs overflow-hidden"
              title="Firebase 로그인 및 계정 관리"
            >
              {currentUser?.photoURL ? (
                <img src={currentUser.photoURL} alt="" className="w-full h-full object-cover" />
              ) : (
                <span>👤</span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 max-w-md mx-auto px-4 pb-24 flex flex-col items-center">
        {/* HERO PROFILE BENTO CARD */}
        <section className={`w-full rounded-[28px] p-6 mb-4.5 transition-all duration-300 ${currentTheme.cardBg} ${currentTheme.cardBorder} shadow-xl shadow-purple-500/5`}>
          <div className="flex flex-col items-center text-center">
            {/* Layered Avatar with Ripple Accent */}
            <div className="relative mb-3.5 group">
              <div className="w-24 h-24 rounded-full p-1 bg-linear-to-tr from-purple-500 via-pink-500 to-amber-400 shadow-xl shadow-purple-500/20 flex items-center justify-center">
                <div className="w-full h-full rounded-full bg-white dark:bg-zinc-900 flex items-center justify-center overflow-hidden">
                  {profile.avatarType === "image" && profile.avatarUrl ? (
                    <img
                      src={profile.avatarUrl}
                      alt={profile.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  ) : (
                    <span className="text-4xl select-none group-hover:scale-110 transition-transform duration-300">
                      {profile.avatarEmoji || "🌸"}
                    </span>
                  )}
                </div>
              </div>

              {/* Camera Upload Button (Owner Only) */}
              {isOwner && (
                <label
                  title="사진 파일 직접 업로드"
                  className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-purple-600 hover:bg-purple-700 text-white border-2 border-white dark:border-zinc-900 flex items-center justify-center cursor-pointer shadow-lg hover:scale-110 transition-all z-20"
                >
                  <CameraIcon className="w-3.5 h-3.5" />
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleAvatarUpload}
                  />
                </label>
              )}

              {/* Online Pulse Dot */}
              {!isOwner && (
                <div className="absolute bottom-1 right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-white dark:border-zinc-900 flex items-center justify-center shadow-md">
                  <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                </div>
              )}
            </div>

            {/* Name & Verified Badge */}
            <div className="flex items-center gap-1.5 mb-1.5">
              <h1 className={`text-xl font-extrabold tracking-tight ${currentTheme.textColor}`}>
                {profile.name}
              </h1>
              <span className="w-4 h-4 rounded-full bg-purple-600 text-white flex items-center justify-center text-[9px] font-bold shadow-xs">
                ✓
              </span>
            </div>

            {/* Status Pills */}
            <div className="flex flex-wrap items-center justify-center gap-1.5 mb-3">
              {profile.statusBadge && (
                <span className={`text-[11px] font-bold px-3 py-1 rounded-full ${currentTheme.accentBadge}`}>
                  {profile.statusBadge}
                </span>
              )}
              {profile.statusMood && (
                <span className="text-[11px] font-medium px-3 py-1 rounded-full bg-black/5 dark:bg-white/10 text-zinc-600 dark:text-zinc-300 backdrop-blur-md">
                  {profile.statusMood}
                </span>
              )}
            </div>

            {/* Bio */}
            <p className={`text-xs max-w-xs leading-relaxed font-medium mb-4.5 ${currentTheme.subTextColor}`}>
              {profile.bio}
            </p>

            {/* Modern Social Dock */}
            <div className="flex items-center justify-center gap-2 p-1.5 rounded-2xl bg-black/5 dark:bg-white/5 backdrop-blur-md border border-black/5 dark:border-white/5">
              {profile.socials
                .filter((s) => s.enabled && s.url)
                .map((s) => (
                  <a
                    key={s.platform}
                    href={s.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 rounded-xl flex items-center justify-center bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:text-purple-600 dark:hover:text-purple-400 hover:scale-115 hover:-translate-y-0.5 transition-all shadow-xs"
                    title={s.platform}
                  >
                    {renderSocialIcon(s.platform)}
                  </a>
                ))}
            </div>
          </div>
        </section>

        {/* BENTO ROW: Music Player Widget */}
        <section className="w-full mb-4">
          <MusicWidget />
        </section>

        {/* BENTO GRID: Stats & Cheer Widget */}
        <section className="w-full grid grid-cols-2 gap-3 mb-4">
          {/* Quick Cheer Card */}
          <div 
            onClick={handleQuickCheer}
            className={`rounded-2xl p-3.5 transition-all duration-300 cursor-pointer ${currentTheme.cardBg} ${currentTheme.cardBorder} hover:shadow-lg hover:-translate-y-0.5 active:scale-95 group`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-bold text-pink-600 dark:text-pink-400">오늘의 응원</span>
              <span className="text-sm group-hover:scale-125 transition-transform">💖</span>
            </div>
            <p className="text-lg font-black text-zinc-900 dark:text-white tracking-tight">
              {cheersCount} <span className="text-xs font-semibold text-zinc-400">하트</span>
            </p>
            <p className="text-[10px] text-zinc-400 mt-0.5">클릭해서 응원 보내기</p>
          </div>

          {/* Quick Traffic & Links Stats */}
          <div className={`rounded-2xl p-3.5 ${currentTheme.cardBg} ${currentTheme.cardBorder}`}>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-bold text-purple-600 dark:text-purple-400">누적 조회수</span>
              <span className="text-sm">🔥</span>
            </div>
            <p className="text-lg font-black text-zinc-900 dark:text-white tracking-tight">
              {totalClicks + 1420} <span className="text-xs font-semibold text-zinc-400">회</span>
            </p>
            <p className="text-[10px] text-zinc-400 mt-0.5">실시간 통계 집계 중</p>
          </div>
        </section>

        {/* BENTO ROW: Tech Stack Chips */}
        <section className="w-full mb-4.5">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {techSkills.map((tech) => (
              <span
                key={tech.name}
                className={`text-[10px] font-bold px-3 py-1 rounded-full bg-linear-to-r ${tech.color} border shadow-2xs whitespace-nowrap shrink-0`}
              >
                {tech.name}
              </span>
            ))}
          </div>
        </section>

        {/* SEARCH & QUICK ACTION BAR */}
        <section className="w-full flex items-center gap-2 mb-3">
          {/* Search Box */}
          <div className="flex-1 relative">
            <SearchIcon className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="링크 및 키워드 검색..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-7 py-2 text-xs rounded-2xl bg-white/70 dark:bg-zinc-900/70 backdrop-blur-xl border border-black/5 dark:border-white/10 text-zinc-800 dark:text-zinc-200 placeholder-zinc-400 outline-none focus:ring-2 focus:ring-purple-400 shadow-xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600"
              >
                <CloseIcon className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Share Modal Trigger */}
          <button
            onClick={() => setIsShareOpen(true)}
            className="flex items-center gap-1 px-3 py-2 rounded-2xl bg-white/70 dark:bg-zinc-900/70 backdrop-blur-xl border border-black/5 dark:border-white/10 text-xs font-bold text-zinc-700 dark:text-zinc-300 hover:bg-white dark:hover:bg-zinc-800 transition-all shadow-xs shrink-0"
            title="마이링크 공유하기"
          >
            <ShareIcon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">공유</span>
          </button>

          {/* Guestbook Modal Trigger */}
          <button
            onClick={() => setIsGuestbookOpen(true)}
            className="flex items-center gap-1 px-3 py-2 rounded-2xl bg-white/70 dark:bg-zinc-900/70 backdrop-blur-xl border border-black/5 dark:border-white/10 text-xs font-bold text-zinc-700 dark:text-zinc-300 hover:bg-white dark:hover:bg-zinc-800 transition-all shadow-xs shrink-0"
            title="방명록 남기기"
          >
            <MessageIcon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">방명록</span>
          </button>

          {/* Owner Full Edit Settings */}
          {isOwner && (
            <button
              onClick={() => setIsEditOpen(true)}
              className="p-2 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white shadow-md shadow-purple-500/20 transition-all shrink-0"
              title="전체 프로필 및 링크 관리"
            >
              <EditIcon className="w-4 h-4" />
            </button>
          )}
        </section>

        {/* CATEGORY FILTER TABS */}
        <section className="w-full flex items-center gap-1.5 overflow-x-auto pb-2 mb-3.5 scrollbar-none">
          {categoryFilters.map((cat) => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`text-[11px] font-bold px-3 py-1 rounded-full transition-all duration-200 whitespace-nowrap shrink-0 ${
                  isSelected
                    ? "bg-zinc-900 text-white dark:bg-white dark:text-zinc-900 shadow-sm scale-105"
                    : "bg-white/60 dark:bg-zinc-900/60 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 border border-black/5 dark:border-white/5"
                }`}
              >
                {cat}
              </button>
            );
          })}
        </section>

        {/* OWNER CREATE LINK FORM (CRUD: Create) */}
        {isOwner && (
          <section className="w-full mb-4">
            <AddLinkForm onAdd={handleAddLink} />
          </section>
        )}

        {/* DATA-DRIVEN LINK CARDS LIST */}
        <section className="w-full space-y-3">
          {isLoading ? (
            <div className="py-16 flex flex-col items-center justify-center space-y-3">
              <div className="w-8 h-8 border-3 border-purple-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-xs font-semibold text-zinc-400">데이터를 불러오는 중입니다...</p>
            </div>
          ) : filteredLinks.length === 0 ? (
            <div className="py-14 px-4 text-center rounded-[24px] bg-white/40 dark:bg-zinc-900/40 border border-dashed border-zinc-300 dark:border-zinc-800">
              <span className="text-2xl mb-2 inline-block">🔍</span>
              <p className="text-sm font-bold text-zinc-700 dark:text-zinc-300">
                {searchQuery ? "검색된 링크가 없습니다." : "해당 카테고리에 링크가 없습니다."}
              </p>
              <p className="text-xs text-zinc-400 mt-1">
                {isOwner ? "위의 버튼을 눌러 첫 링크를 추가해보세요!" : "다른 카테고리나 검색어를 선택해보세요."}
              </p>
            </div>
          ) : (
            filteredLinks.map((link) => (
              <LinkCard
                key={link.id}
                link={link}
                theme={profile.theme}
                isOwner={isOwner}
                onUpdate={handleUpdateLink}
                onRequestDelete={(target) => setDeleteTargetLink(target)}
                onLinkClick={handleLinkClick}
              />
            ))
          )}
        </section>

        {/* BOTTOM BRAND FOOTER */}
        <footer className="mt-14 text-center space-y-1.5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/50 dark:bg-zinc-900/50 backdrop-blur-md border border-black/5 dark:border-white/5 text-[10px] text-zinc-400">
            <span>✨ Crafted with Next.js & Tailwind</span>
            <span>•</span>
            <button
              onClick={() => setIsGuestbookOpen(true)}
              className="text-purple-600 dark:text-purple-400 font-semibold hover:underline"
            >
              방명록 남기기
            </button>
          </div>
          <p className="text-[10px] text-zinc-400/70 font-mono">
            © 2026 {profile.name} • All rights reserved.
          </p>
        </footer>
      </main>

      {/* ALL MODALS */}
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
      <ShareModal isOpen={isShareOpen} onClose={() => setIsShareOpen(false)} title={profile.name} />
      <GuestbookModal isOpen={isGuestbookOpen} onClose={() => setIsGuestbookOpen(false)} />
      <EditModal
        isOpen={isEditOpen}
        onClose={() => setIsEditOpen(false)}
        data={profile}
        onSave={async (newData) => {
          setProfile(newData);
          setLinks(newData.links);
          await firestoreService.updateProfile(newData);
          showToast("전체 설정이 저장되었습니다!");
        }}
        onReset={async () => {
          const res = await firestoreService.resetToDefault();
          setProfile(res.profile);
          setLinks(res.links);
          showToast("기본 데이터로 초기화되었습니다.");
        }}
      />
      <DeleteConfirmModal
        isOpen={Boolean(deleteTargetLink)}
        link={deleteTargetLink}
        onClose={() => setDeleteTargetLink(null)}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}

export default function Home() {
  return (
    <AuthProvider>
      <MyLinkApp />
    </AuthProvider>
  );
}

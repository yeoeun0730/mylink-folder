# 📱 마이링크 (MyLink)

Next.js와 TypeScript 기반의 나만의 링크 모음 웹 애플리케이션 및 모던 프론트엔드/BaaS 엔지니어링 실습 프로젝트입니다.

---

## 🚀 프로젝트 개요 & 포함된 핵심 개념 13가지

1. **PRD (제품 요구사항 정의서)**: 배경, 타겟 페르소나, 핵심 기능 스코프 및 성공 지표(KPI) 정의
2. **사용자 시나리오 (User Scenario & Flow)**: 소유자(Owner) 관리 플로우 vs 방문자(Guest) 브라우징 플로우
3. **와이어프레임 & 정보구조도 (IA)**: 모바일 퍼스트 반응형 레이아웃 및 컴포넌트 계층도
4. **디자인 시스템 (Design System)**: 5가지 테마(라벤더, 미드나잇, 선셋, 에메랄드, 미니멀), 색상 토큰, 타이포그래피, 마이크로 인터랙션
5. **데이터로 화면 생성 (Data-driven UI Rendering)**: 상태 배열을 단일 진실 공급원(SSOT)으로 삼아 선언적으로 UI를 렌더링
6. **CRUD 복습과 폼 (CRUD & Form Handling)**: Create(신규 생성), Read(조회/검색/필터), Update(인라인+모달), Delete(확인 모달)
7. **데이터 흐름과 입력 검증 (Data Flow & Validation)**: 단방향 데이터 흐름, 실시간 URL 정규식 검사, 제목 글자 수 제한, 유효성에 따른 버튼 제어
8. **BaaS와 Firebase (BaaS Concepts)**: 서버리스 아키텍처, 전통 서버 대비 장단점, Firebase 핵심 서비스군
9. **Firestore 데이터 구조와 설계 (NoSQL Data Modeling)**: `users/{userId}` 문서 및 `links/{linkId}` 서브컬렉션 설계, 보안 규칙(`firestore.rules`)
10. **Update 개념과 인라인 편집 UI (Inline Editing & Optimistic UI)**: 카드 위에서 직접 텍스트 수정(Enter/ESC) 및 낙관적 UI 업데이트
11. **Delete 개념과 모달 팝업 UX (Destructive Action Modal UX)**: 실수 방지 삭제 확인 모달, 소프트 딜리트(숨김) vs 하드 딜리트(영구 삭제) 옵션
12. **인증 개념과 소셜 로그인 (OAuth 2.0 & Social Auth)**: 인증(Authentication) vs 인가(Authorization), Google/GitHub/Kakao 소셜 로그인 플로우
13. **Firebase Auth와 로그인 흐름 (Auth Observer & Guard)**: `onAuthStateChanged` 상태 감지, 소유자 모드와 방문자 뷰 모드 실시간 전환

---

## 🛠️ 기술 스택

- **Framework**: Next.js (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS v4
- **BaaS Layer**: Firebase Auth & Cloud Firestore (하이브리드 오프라인/에뮬레이터 지원)
- **Architecture**: Controlled Component Forms, Optimistic UI Updates, Modular Service Pattern

---

## 💻 실행 방법

### 개발 서버 실행
```bash
npm run dev
```
브라우저에서 [http://localhost:3000](http://localhost:3000) 접속

### 프로덕션 빌드
```bash
npm run build
```

---

## 📁 주요 디렉터리 및 파일 구조

```
my-link-ye/
├── firestore.rules               # Firestore NoSQL 보안 규칙
├── src/
│   ├── app/
│   │   ├── globals.css           # Tailwind CSS v4 설정 및 커스텀 스타일
│   │   ├── layout.tsx            # 메타데이터 및 글로벌 레이아웃
│   │   └── page.tsx              # 마이링크 통합 메인 애플리케이션
│   ├── components/
│   │   ├── AddLinkForm.tsx       # 실시간 검증 기능이 포함된 링크 생성 폼
│   │   ├── AuthModal.tsx         # 소셜 로그인 (Google, GitHub, Kakao, Email) 모달
│   │   ├── DeleteConfirmModal.tsx# 파괴적 삭제 확인 팝업 모달 UX
│   │   ├── EditModal.tsx         # 전체 프로필/링크/소셜/백업 편집 모달
│   │   ├── GuestbookModal.tsx    # 방문자 방명록 및 실시간 하트 응원 모달
│   │   ├── Icons.tsx             # 커스텀 SVG 아이콘 모음
│   │   ├── LinkCard.tsx          # 인라인 편집(Inline Edit) 및 클릭수 추적 카드
│   │   ├── ShareModal.tsx        # URL 복사 및 SVG QR 코드 공유 모달
│   │   └── ThemeSelector.tsx     # 5가지 감성 테마 실시간 전환기
│   ├── data/
│   │   └── defaultData.ts        # 여은의 초기 기본 프로필, 링크 및 테마 스타일
│   ├── lib/
│   │   ├── authContext.tsx       # Firebase Auth Context 및 인증 상태 관리
│   │   ├── firebase.ts           # Firebase SDK 초기화 및 하이브리드 BaaS 설정
│   │   └── firestoreService.ts   # Firestore NoSQL CRUD 서비스 레이어
│   └── types/
│       └── index.ts              # TypeScript 인터페이스 정의
```
